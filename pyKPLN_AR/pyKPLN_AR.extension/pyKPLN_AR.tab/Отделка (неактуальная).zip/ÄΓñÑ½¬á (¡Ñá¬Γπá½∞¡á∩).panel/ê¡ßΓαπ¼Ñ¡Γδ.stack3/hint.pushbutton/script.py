# -*- coding: utf-8 -*-
"""
FW_Hint

"""
__author__ = 'Igor Perfilyev - envato.perfilev@gmail.com'
__title__ = "Help"
__doc__ = 'Подробная инструкция на Notion.so' \

"""
Архитекурное бюро KPLN

"""

import webbrowser
webbrowser.open('https://kpln.kdb24.ru/article/62616/')