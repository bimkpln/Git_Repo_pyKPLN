# -*- coding: utf-8 -*-
"""
EEFFpy

"""
__author__ = 'Igor Perfilyev - envato.perfilev@gmail.com'
__title__ = "Площадь\nмногосл."
__doc__ = 'KPLN Энергоэффективность\n' \
          'Расчет общей площади пирогов заданной конфигурации\n(при раздельном моделировании слоев)\nНе работает с криволинейными элементами!\nRevit 2018 не ниже' \
"""
KPLN

"""
import math
import webbrowser
import re
import os
from rpw import doc, uidoc, DB, UI, db, ui, revit
from pyrevit import script
from pyrevit import forms
from pyrevit import revit as REVIT
from pyrevit import DB, UI
from pyrevit.revit import Transaction, selection
from System.Collections.Generic import List

from System.Collections.Generic import *
import System
from System.Windows.Forms import *
from System.Drawing import *
import re
from itertools import chain
import datetime
from rpw.ui.forms import Alert

class CreateWindow(Form):
	def __init__(self): 
		#INIT
		self.Name = "KPLN_AR_Энергоэффективность"
		self.Text = "KPLN Энергоэффективность"
		self.Size = Size(800, 350)
		self.MinimumSize = Size(800, 350)
		self.MaximumSize = Size(800, 350)
		self.MaximizeBox = False
		self.MinimizeBox = False
		self.ControlBox = True
		self.FormBorderStyle = FormBorderStyle.FixedDialog
		self.TopMost = True
		self.stop = False
		self.BackColor = Color.FromArgb(255, 255, 255)
		self.Icon = Icon("Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\icon.ico")
		self.img_first = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\01.png')
		self.img_first_inactive = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\01_inactive.png')
		self.img_first_active = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\01_active.png')
		self.img_first_error = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\01_error.png')
		self.img_second = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\02.png')
		self.img_second_inactive = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\02_inactive.png')
		self.img_second_active = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\02_active.png')
		self.img_second_error = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\02_error.png')
		self.img_third = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\03.png')
		self.img_third_inactive = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\03_inactive.png')
		self.img_third_active = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\03_active.png')
		self.img_third_error = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\03_error.png')
		self.img_axis = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\Axis.png')
		
		self.Paint += self.OnPaint
		self.MouseClick += self.SwapPictures
		self.preview = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\Frame_Empty.png')
		self.element = None
		self.preview_text = "Эскиз:\n<Типоразмер>"

		self.img_1 = self.img_first_inactive
		self.img_2 = self.img_second_inactive
		self.img_3 = self.img_third_inactive
		self.img_1_def = self.img_first_inactive
		self.img_2_def = self.img_second_inactive
		self.img_3_def = self.img_third_inactive
		self.active = 0
		self.wall_1 = False
		self.wall_2 = False
		self.wall_3 = False
		self.wall_1_type = "{} : {}".format("", "Не выбрано")
		self.wall_2_type = "{} : {}".format("", "Не выбрано")
		self.wall_3_type = "{} : {}".format("", "Не выбрано")
		self.geometry_second = []

		self.gb = GroupBox()
		self.gb.Text = "Параметры"
		self.gb.Size = Size(540, 210)
		self.gb.Location = Point(147, 44)
		self.gb.Parent = self

		self.btn_run = Button(Text = "Рассчитать")
		self.btn_run.Location = Point(147, 270)
		self.btn_run.Parent = self
		self.btn_run.Click += self.run		

		self.btn_help = Button(Text = "Инструкция")
		self.btn_help.Location = Point(232, 270)
		self.btn_help.Parent = self
		self.btn_help.Click += self.go_to_help

		self.lb_1 = Label(Text = "Активность:")
		self.lb_1.Location = Point(15, 25)
		self.lb_1.Parent = self.gb

		self.cb_enabled = ComboBox()
		self.cb_enabled.SelectedIndexChanged += self.CblOnChanged_1
		self.cb_enabled.DropDownStyle = ComboBoxStyle.DropDownList
		self.cb_enabled.Size = Size(100, 10)
		self.cb_enabled.Location = Point(15, 50)
		self.cb_enabled.Parent = self.gb
		self.cb_enabled.Items.Add("Да")
		self.cb_enabled.Items.Add("Нет")

		self.lb_2 = Label(Text = "Типоразмер стены/витража:")
		self.lb_2.Size = Size(500, 15)
		self.lb_2.Location = Point(15, 80)
		self.lb_2.Parent = self.gb

		self.cb = ComboBox()
		self.cb.SelectedIndexChanged += self.CblOnChanged_2
		self.cb.DropDownStyle = ComboBoxStyle.DropDownList
		self.cb.Size = Size(510, 10)
		self.cb.Location = Point(15, 105)
		self.cb.Parent = self.gb
		wall_collector = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_Walls).WhereElementIsNotElementType().ToElements()
		self.elements = []
		self.elements.append(["", "Не выбрано", False, Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\Frame_Empty.png')])
		self.cb.Items.Add("{} : {}".format("", "Не выбрано"))
		self.w_elements = []
		self.f_elements = []
		self.floors_check = []
		self.uniq_check = []
		for element in wall_collector:
			try:
				if not self.contains("{} : {}".format(element.WallType.FamilyName, element.Name), self.uniq_check):
					self.uniq_check.append("{} : {}".format(element.WallType.FamilyName, element.Name))
					self.elements.append([element.WallType.FamilyName, element.Name, element.WallType, element.WallType.GetPreviewImage(Size(70, 70))])
					self.w_elements.append([element.WallType.FamilyName, element.Name, element.WallType, element.WallType.GetPreviewImage(Size(70, 70))])
			except: pass
		floor_collector = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_Floors).WhereElementIsNotElementType().ToElements()
		for element in floor_collector:
			try:
				if not self.contains("{} : {}".format(element.FloorType.FamilyName, element.Name), self.floors_check):
					self.floors_check.append("{} : {}".format(element.FloorType.FamilyName, element.Name))
					self.elements.append([element.FloorType.FamilyName, element.Name, element.FloorType, element.FloorType.GetPreviewImage(Size(70, 70))])
					self.f_elements.append([element.FloorType.FamilyName, element.Name, element.FloorType, element.FloorType.GetPreviewImage(Size(70, 70))])
			except: pass
		self.lb_3 = Label(Text = "Примечание:\nИнструмент не гарантирует 100% точности. Для наиболее достоверного расчета необходимо отказаться от инструмента «Редактирование профиля стены».")
		self.lb_3.Size = Size(500, 50)
		self.lb_3.Location = Point(15, 130)
		self.lb_3.Parent = self.gb

		self.lb_4 = Label(Text = "")
		self.lb_4.Size = Size(90, 200)
		self.lb_4.Location = Point(700, 130)
		self.lb_4.Parent = self

		self.lb_5 = Label(Text = "")
		self.lb_5.Size = Size(400, 36)
		self.lb_5.Location = Point(200, 10)
		self.lb_5.Parent = self

		self.CenterToScreen()

		self.UpdateActive()

	def go_to_help(self, sender, args):
		webbrowser.open('https://www.notion.so/kpln/4d4cf0f024264cf78f6374ad81a24fe4')

	def get_max_solid(self, list):
		try:
			max = 0
			solid = False
			for i in list:
				try:
					if i.SurfaceArea > max and i.Faces.Size == 1:
						max = i.SurfaceArea
						solid = i
				except: pass
			if solid != False:
				return solid
			max = 0
			solid = False
			for i in list:
				try:
					if i.SurfaceArea > max and i.Faces.Size != 0:
						max = i.SurfaceArea
						solid = i
				except: pass
			if solid != False:
				return solid
		except: return False

	def contains(self, item, list):
		for i in list:
			if i == item:
				return True
		return False

	def update_items(self, withfloors = False):
		self.cb.Items.Clear()
		self.cb.Items.Add("{} : {}".format("", "Не выбрано"))
		for i in self.w_elements:
			self.cb.Items.Add("{} : {}".format(i[0], i[1]))
		if withfloors:
			for i in self.f_elements:
				self.cb.Items.Add("{} : {}".format(i[0], i[1]))

	def get_max_face(self, list, normals):
		try:
			max = 0
			face = False
			for i in list:
				if i.Area > max and (str(i.ComputeNormal(DB.UV(0, 0))) == str(normals) or str(i.ComputeNormal(DB.UV(0, 0)).Negate()) == str(normals)):
					max = i.Area
					face = i
			return face
		except: return False

	def get_max_face_floor(self, list, normals):
		try:
			max = 0
			face = False
			for i in list:
				if i.Area > max and str(i.ComputeNormal(DB.UV(0, 0))) != str(normals) and str(i.ComputeNormal(DB.UV(0, 0)).Negate()) != str(normals) and str(i.ComputeNormal(DB.UV(0, 0))) != str(normals.Negate()) and str(i.ComputeNormal(DB.UV(0, 0)).Negate()) != str(normals.Negate()):
					max = i.Area
					face = i
			return face
		except: return False

	def CblOnChanged_1(self, sender, event):
		if self.active == 1:
			if self.cb_enabled.Text == "Да":
				self.wall_1 = True
				if self.wall_1_type != "{} : {}".format("", "Не выбрано"):
					self.img_1_def = self.img_first
				else:
					self.img_1_def = self.img_first_error
				self.cb.Enabled = True
			elif self.cb_enabled.Text == "Нет":
				self.wall_1 = False
				self.img_1_def = self.img_first_inactive
				self.cb.Enabled = False
		elif self.active == 2:
			if self.cb_enabled.Text == "Да":
				self.wall_2 = True
				if self.wall_2_type != "{} : {}".format("", "Не выбрано"):
					self.img_2_def = self.img_second
				else:
					self.img_2_def = self.img_second_error
				self.cb.Enabled = True
			elif self.cb_enabled.Text == "Нет":
				self.wall_2 = False
				self.img_2_def = self.img_second_inactive
				self.cb.Enabled = False
		elif self.active == 3:
			if self.cb_enabled.Text == "Да":
				self.wall_3 = True
				if self.wall_3_type != "{} : {}".format("", "Не выбрано"):
					self.img_3_def = self.img_third
				else:
					self.img_3_def = self.img_third_error
				self.cb.Enabled = True
			elif self.cb_enabled.Text == "Нет":
				self.wall_3 = False
				self.img_3_def = self.img_third_inactive
				self.cb.Enabled = False
		self.Refresh()

	def CblOnChanged_2(self, sender, event):
		for i in self.elements:
			if self.cb.Text == "{} : {}".format(i[0], i[1]):
				if self.active == 1:
					self.wall_1_type = self.cb.Text
					if self.cb_enabled.Text == "Да":
						self.wall_1 = True
						if self.wall_1_type != "{} : {}".format("", "Не выбрано"):
							self.img_1_def = self.img_first
						else:
							self.img_1_def = self.img_first_error
					elif self.cb_enabled.Text == "Нет":
						self.wall_1 = False
						self.img_1_def = self.img_first_inactive
				elif self.active == 2:
					self.wall_2_type = self.cb.Text
					if self.cb_enabled.Text == "Да":
						self.wall_2 = True
						if self.wall_2_type != "{} : {}".format("", "Не выбрано"):
							self.img_2_def = self.img_second
						else:
							self.img_2_def = self.img_second_error
					elif self.cb_enabled.Text == "Нет":
						self.wall_2 = False
						self.img_2_def = self.img_second_inactive
				elif self.active == 3:
					self.wall_3_type = self.cb.Text
					if self.cb_enabled.Text == "Да":
						self.wall_3 = True
						if self.wall_3_type != "{} : {}".format("", "Не выбрано"):
							self.img_3_def = self.img_third
						else:
							self.img_3_def = self.img_third_error
					elif self.cb_enabled.Text == "Нет":
						self.wall_3 = False
						self.img_3_def = self.img_third_inactive
				try:
					if i[3] != None:
						self.preview = i[3]
					else:
						self.preview = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\Frame_Empty.png')
				except Exception as e:
					forms.alert(str(e))
		self.define_floors()
		self.Refresh()

	def UpdateActive(self):
		if self.active == 0:
			self.lb_4.Text = ""
			self.cb_enabled.Enabled = False
			self.cb_enabled.Text = "Нет"
			self.cb.Text = "{} : {}".format("", "Не выбрано")
			self.cb.Enabled = False
		elif self.active == 1:
			self.lb_4.Text = self.preview_text
			self.cb_enabled.Enabled = True
			if self.wall_1:
				self.cb_enabled.Text = "Да"
				self.cb.Enabled = True
			else:
				self.cb_enabled.Text = "Нет"
				self.cb.Enabled = False
			self.cb.Text = self.wall_1_type
		elif self.active == 2:
			self.lb_4.Text = self.preview_text
			self.cb_enabled.Enabled = True
			if self.wall_2:
				self.cb_enabled.Text = "Да"
				self.cb.Enabled = True
			else:
				self.cb_enabled.Text = "Нет"
				self.cb.Enabled = False
			self.cb.Text = self.wall_2_type
		elif self.active == 3:
			self.lb_4.Text = self.preview_text
			self.cb_enabled.Enabled = True
			if self.wall_3:
				self.cb_enabled.Text = "Да"
				self.cb.Enabled = True
			else:
				self.cb_enabled.Text = "Нет"
				self.cb.Enabled = False
			self.cb.Text = self.wall_3_type

	def OnPaint(self, event):
		g = event.Graphics
		r = Rectangle(150, 5, 42, 36)
		if (self.wall_1 and self.wall_1_type == "{} : {}".format("", "Не выбрано")) or (self.wall_2 and self.wall_2_type == "{} : {}".format("", "Не выбрано")) or (self.wall_3 and self.wall_3_type == "{} : {}".format("", "Не выбрано")):
			g.DrawImage(Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\Error.png'), r)
			self.lb_5.Text = "ПРЕДУПРЕЖДЕНИЕ:\nНеобходимо выбрать типоразмер для расчета!"
			if self.btn_run.Enabled:
				self.btn_run.Enabled = False
		elif (self.wall_1 and not self.wall_2 and not self.wall_3) or (not self.wall_1 and self.wall_2 and not self.wall_3) or (not self.wall_1 and not self.wall_2 and self.wall_3):
			g.DrawImage(Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\Error.png'), r)
			self.lb_5.Text = "ПРЕДУПРЕЖДЕНИЕ:\nНеобходимо как минимум два сля для расчета!"
			if self.btn_run.Enabled:
				self.btn_run.Enabled = False
		else: 
			self.btn_run.Enabled = True
			self.lb_5.Text = ""
		if self.active != 0:
			r = Rectangle(700, 50, 70, 70)
			g.DrawImage(self.preview, r)
			r = Rectangle(700, 50, 70, 70)
			g.DrawImage(Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\Frame.png'), r)
		r = Rectangle(35, 50, self.img_3.Width, self.img_3.Height)
		g.DrawImage(self.img_3, r)
		r = Rectangle(53, 50, self.img_2.Width, self.img_2.Height)
		g.DrawImage(self.img_2, r)
		r = Rectangle(83, 50, self.img_1.Width, self.img_1.Height)
		g.DrawImage(self.img_1, r)
		r = Rectangle(50, 23, self.img_axis.Width, self.img_axis.Height)
		g.DrawImage(self.img_axis, r)
		g.Dispose()

	def define_floors(self):
		if self.contains(self.wall_1_type, self.floors_check):
			self.img_first = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\01.png')
			self.img_first_inactive = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\01_inactive.png')
			self.img_first_active = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\01_active.png')
			self.img_first_error = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\01_error.png')
			self.img_second = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\02.png')
			self.img_second_inactive = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\02_inactive.png')
			self.img_second_active = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\02_active.png')
			self.img_second_error = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\02_error.png')
			self.img_third = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\03.png')
			self.img_third_inactive = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\03_inactive.png')
			self.img_third_active = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\03_active.png')
			self.img_third_error = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\03_error.png')
		else:
			self.img_first = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\01_walls.png')
			self.img_first_inactive = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\01_inactive_walls.png')
			self.img_first_active = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\01_active_walls.png')
			self.img_first_error = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\01_error_walls.png')
			self.img_second = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\02_walls.png')
			self.img_second_inactive = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\02_inactive_walls.png')
			self.img_second_active = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\02_active_walls.png')
			self.img_second_error = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\02_error_walls.png')
			self.img_third = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\03_walls.png')
			self.img_third_inactive = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\03_inactive_walls.png')
			self.img_third_active = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\03_active_walls.png')
			self.img_third_error = Image.FromFile('Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Энергоэффективнось.panel\\GetEdgeArea.pushbutton\\sourse\\03_error_walls.png')
		#
		if self.wall_1:
			if self.wall_1_type != "{} : {}".format("", "Не выбрано"):
				self.img_1_def = self.img_first
			else:
				self.img_1_def = self.img_first_error
		else:
			self.img_1_def = self.img_first_inactive
		if self.wall_2:
			if self.wall_2_type != "{} : {}".format("", "Не выбрано"):
				self.img_2_def = self.img_second
			else:
				self.img_2_def = self.img_second_error
		else:
			self.img_2_def = self.img_second_inactive
		if self.wall_3:
			if self.wall_3_type != "{} : {}".format("", "Не выбрано"):
				self.img_3_def = self.img_third
			else:
				self.img_3_def = self.img_third_error
		else:
			self.img_3_def = self.img_third_inactive
		#
		if self.active == 3:
			self.img_3 = self.img_third_active
			self.img_2 = self.img_2_def
			self.img_1 = self.img_1_def
		elif self.active == 2:
			self.img_3 = self.img_3_def
			self.img_2 = self.img_second_active
			self.img_1 = self.img_1_def
		elif self.active == 1:
			self.img_3 = self.img_3_def
			self.img_2 = self.img_2_def
			self.img_1 = self.img_first_active
		else:
			self.img_3 = self.img_3_def
			self.img_2 = self.img_2_def
			self.img_1 = self.img_1_def

	def SwapPictures(self, sender, event):
		if event.X >= 35 and event.X <= 35 + self.img_3.Width and event.Y >= 50 and event.Y <= 50 + self.img_3.Height:
			self.active = 3
			self.update_items(False)
		elif event.X >= 53 and event.X <= 53 + self.img_2.Width and event.Y >= 50 and event.Y <= 50 + self.img_2.Height:
			self.active = 2
			self.update_items(False)
		elif event.X >= 83 and event.X <= 83 + self.img_1.Width and event.Y >= 50 and event.Y <= 50 + self.img_1.Height:
			self.active = 1
			self.update_items(True)
		else:
			self.active = 0
			self.update_items(False)
		self.define_floors()
		self.Refresh()
		self.UpdateActive()

	def boolean_intersection(self, solid_1, solid_2, normali):
		s_intersect = DB.BooleanOperationsUtils.ExecuteBooleanOperation(solid_1, solid_2, DB.BooleanOperationsType.Intersect)
		if abs(s_intersect.Volume) > 0.0000001:	
			face = self.get_max_face(s_intersect.Faces, normali)
			if face != False:
				return [face, s_intersect]
			else:
				return False
		return False

	def boolean_intersection_floor(self, solid_1, solid_2, normali):
		s_intersect = DB.BooleanOperationsUtils.ExecuteBooleanOperation(solid_1, solid_2, DB.BooleanOperationsType.Intersect)
		if abs(s_intersect.Volume) > 0.0000001:	
			face = self.get_max_face_floor(s_intersect.Faces, normali)
			if face != False:
				return [face, s_intersect]
			else:
				return False
		return False

	def run(self, sender, args):
		try:
			self.Hide()
			area = 0
			floormode = False
			types = [self.wall_1_type, self.wall_2_type, self.wall_3_type]
			elements = [[],[],[]]
			collector_walls = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_Walls).WhereElementIsNotElementType().ToElements()
			collector_floors = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_Floors).WhereElementIsNotElementType().ToElements()
			if self.contains(self.wall_1_type, self.floors_check):
				floormode = True
				for element in collector_floors:
					name = "{} : {}".format(element.FloorType.FamilyName, element.Name)
					if name == types[0]:
						elements[0].append(element)
				for element in collector_walls:
					try:
						name = "{} : {}".format(element.WallType.FamilyName, element.Name)
						if name == types[1]:
							elements[1].append(element)
						if name == types[2]:
							elements[2].append(element)
					except: pass
			else:
				for element in collector_walls:
					try:
						for i in range(0,3):
							name = "{} : {}".format(element.WallType.FamilyName, element.Name)
							if name == types[i]:
								elements[i].append(element)
					except: pass
			geometry = [[],[],[]]
			self.geometry_second = []
			for i in range(0,3):
				if len(elements[i]) > 0:
					for element in elements[i]:
						options = DB.Options()
						options.ComputeReferences = False
						options.IncludeNonVisibleObjects = True
						g_geometry = element.get_Geometry(options)
						col = List[DB.GeometryObject]()
						solids = []
						for geometry_object in g_geometry:
							if geometry_object.GetType() != DB.Line:
								solids.append(geometry_object)
						max_solid = self.get_max_solid(solids)
						faces = max_solid.Faces
						thatface = False
						if i == 0 and floormode:
							for z in faces:
								if str(z.ComputeNormal(DB.UV(0, 0))) == str(DB.XYZ(0,0,1)):
									thatface = z
							normal = DB.XYZ(0,0,1)
							if thatface != False:
								geometry[i].append([max_solid, normal, thatface])
						else:
							normal = faces[0].ComputeNormal(DB.UV(0, 0))
							geometry[i].append([max_solid, normal, faces[0]])
			if self.wall_1 == True and self.wall_2 == True and self.wall_3 == False:
				for geo_1 in geometry[0]:
					for geo_2 in geometry[1]:
						if floormode:
							solid_1 = geo_1[0]
							curveloop_2 = geo_2[2].GetEdgesAsCurveLoops()
							faces_2 = geo_2[0].Faces[0].GetSurface()
							normal_1 = DB.XYZ(0,0,1)
							normal_2 = geo_2[1]
							n_normal_2 = normal_2.Negate()
							distance = 1
							solid_2 = DB.GeometryCreationUtilities.CreateExtrusionGeometry(curveloop_2, normal_2, distance)
							n_solid_2 = DB.GeometryCreationUtilities.CreateExtrusionGeometry(curveloop_2, n_normal_2, distance)
							face = self.boolean_intersection_floor(solid_1, solid_2, normal_1)
							if face:
								area += face[0].Area * 0.092903
							else:
								face = self.boolean_intersection_floor(solid_1, n_solid_2, normal_1)
								if face:
									area += face[0].Area * 0.092903
								else:
									pass
						else:
							curveloop_1 = geo_1[2].GetEdgesAsCurveLoops()
							curveloop_2 = geo_2[2].GetEdgesAsCurveLoops()
							faces_1 = geo_1[0].Faces[0].GetSurface()
							faces_2 = geo_2[0].Faces[0].GetSurface()
							normal_1 = geo_1[1]
							n_normal_1 = normal_1.Negate()
							normal_2 = geo_2[1]
							n_normal_2 = normal_2.Negate()
							distance = 1
							solid_1 = DB.GeometryCreationUtilities.CreateExtrusionGeometry(curveloop_1, normal_1, distance)
							n_solid_1 = DB.GeometryCreationUtilities.CreateExtrusionGeometry(curveloop_1, n_normal_1, distance)
							solid_2 = DB.GeometryCreationUtilities.CreateExtrusionGeometry(curveloop_2, normal_2, distance)
							n_solid_2 = DB.GeometryCreationUtilities.CreateExtrusionGeometry(curveloop_2, n_normal_2, distance)
							face = self.boolean_intersection(solid_1, solid_2, normal_1)
							if face:
								area += face[0].Area * 0.092903
							else:
								face = self.boolean_intersection(n_solid_1, solid_2, normal_1)
								if face:
									area += face[0].Area * 0.092903
								else:
									face = self.boolean_intersection(solid_1, n_solid_2, normal_1)
									if face:
										area += face[0].Area * 0.092903
									else:
										face = self.boolean_intersection(n_solid_1, n_solid_2, normal_1)
										if face:
											area += face[0].Area * 0.092903
										else: 
											pass
			elif self.wall_1 == True and self.wall_2 == True and self.wall_3 == True:
				for geo_1 in geometry[0]:
					for geo_2 in geometry[1]:
						if floormode:
							solid_1 = geo_1[0]
							curveloop_2 = geo_2[2].GetEdgesAsCurveLoops()
							faces_2 = geo_2[0].Faces[0].GetSurface()
							normal_1 = DB.XYZ(0,0,1)
							normal_2 = geo_2[1]
							n_normal_2 = normal_2.Negate()
							distance = 1
							solid_2 = DB.GeometryCreationUtilities.CreateExtrusionGeometry(curveloop_2, normal_2, distance)
							n_solid_2 = DB.GeometryCreationUtilities.CreateExtrusionGeometry(curveloop_2, n_normal_2, distance)
							face = self.boolean_intersection_floor(solid_1, solid_2, normal_1)
							if face:
								self.geometry_second.append([face[1], face[0].ComputeNormal(DB.UV(0, 0)), face[0]])
							else:
								face = self.boolean_intersection_floor(solid_1, n_solid_2, normal_1)
								if face:
									self.geometry_second.append([face[1], face[0].ComputeNormal(DB.UV(0, 0)), face[0]])
								else:
									pass
						else:
							curveloop_1 = geo_1[2].GetEdgesAsCurveLoops()
							curveloop_2 = geo_2[2].GetEdgesAsCurveLoops()
							faces_1 = geo_1[0].Faces[0].GetSurface()
							faces_2 = geo_2[0].Faces[0].GetSurface()
							normal_1 = geo_1[1]
							n_normal_1 = normal_1.Negate()
							normal_2 = geo_2[1]
							n_normal_2 = normal_2.Negate()
							distance = 1
							solid_1 = DB.GeometryCreationUtilities.CreateExtrusionGeometry(curveloop_1, normal_1, distance)
							n_solid_1 = DB.GeometryCreationUtilities.CreateExtrusionGeometry(curveloop_1, n_normal_1, distance)
							solid_2 = DB.GeometryCreationUtilities.CreateExtrusionGeometry(curveloop_2, normal_2, distance)
							n_solid_2 = DB.GeometryCreationUtilities.CreateExtrusionGeometry(curveloop_2, n_normal_2, distance)
							face = self.boolean_intersection(solid_1, solid_2, normal_1)
							if face:
								self.geometry_second.append([face[1], normal_1, face[0]])
							else:
								face = self.boolean_intersection(n_solid_1, solid_2, normal_1)
								if face:
									self.geometry_second.append([face[1], normal_1, face[0]])
								else:
									face = self.boolean_intersection(solid_1, n_solid_2, normal_1)
									if face:
										self.geometry_second.append([face[1], normal_1, face[0]])
									else:
										face = self.boolean_intersection(n_solid_1, n_solid_2, normal_1)
										if face:
											self.geometry_second.append([face[1], normal_1, face[0]])
										else: 
											pass		
				for geo_1 in self.geometry_second:
					for geo_2 in geometry[2]:
						curveloop_1 = geo_1[2].GetEdgesAsCurveLoops()
						curveloop_2 = geo_2[2].GetEdgesAsCurveLoops()
						faces_1 = geo_1[0].Faces[0].GetSurface()
						faces_2 = geo_2[0].Faces[0].GetSurface()
						normal_1 = geo_1[1]
						n_normal_1 = normal_1.Negate()
						normal_2 = geo_2[1]
						n_normal_2 = normal_2.Negate()
						distance = 1
						solid_1 = DB.GeometryCreationUtilities.CreateExtrusionGeometry(curveloop_1, normal_1, distance)
						n_solid_1 = DB.GeometryCreationUtilities.CreateExtrusionGeometry(curveloop_1, n_normal_1, distance)
						solid_2 = DB.GeometryCreationUtilities.CreateExtrusionGeometry(curveloop_2, normal_2, distance)
						n_solid_2 = DB.GeometryCreationUtilities.CreateExtrusionGeometry(curveloop_2, n_normal_2, distance)
						face = self.boolean_intersection(solid_1, solid_2, normal_1)
						if face:
							area += face[0].Area * 0.092903
						else:
							face = self.boolean_intersection(n_solid_1, solid_2, normal_1)
							if face:
								area += face[0].Area * 0.092903
							else:
								face = self.boolean_intersection(solid_1, n_solid_2, normal_1)
								if face:
									area += face[0].Area * 0.092903
								else:
									face = self.boolean_intersection(n_solid_1, n_solid_2, normal_1)
									if face:
										area += face[0].Area * 0.092903
									else: pass
			elif self.wall_1 == True and self.wall_2 == False and self.wall_3 == True:
				for geo_1 in geometry[0]:
					for geo_2 in geometry[2]:
						if floormode:
							solid_1 = geo_1[0]
							curveloop_2 = geo_2[2].GetEdgesAsCurveLoops()
							faces_2 = geo_2[0].Faces[0].GetSurface()
							normal_1 = DB.XYZ(0,0,1)
							normal_2 = geo_2[1]
							n_normal_2 = normal_2.Negate()
							distance = 1
							solid_2 = DB.GeometryCreationUtilities.CreateExtrusionGeometry(curveloop_2, normal_2, distance)
							n_solid_2 = DB.GeometryCreationUtilities.CreateExtrusionGeometry(curveloop_2, n_normal_2, distance)
							face = self.boolean_intersection_floor(solid_1, solid_2, normal_1)
							if face:
								area += face[0].Area * 0.092903
							else:
								face = self.boolean_intersection_floor(solid_1, n_solid_2, normal_1)
								if face:
									area += face[0].Area * 0.092903
								else:
									pass
						else:
							curveloop_1 = geo_1[2].GetEdgesAsCurveLoops()
							curveloop_2 = geo_2[2].GetEdgesAsCurveLoops()
							faces_1 = geo_1[0].Faces[0].GetSurface()
							faces_2 = geo_2[0].Faces[0].GetSurface()
							normal_1 = geo_1[1]
							n_normal_1 = normal_1.Negate()
							normal_2 = geo_2[1]
							n_normal_2 = normal_2.Negate()
							distance = 1
							solid_1 = DB.GeometryCreationUtilities.CreateExtrusionGeometry(curveloop_1, normal_1, distance)
							n_solid_1 = DB.GeometryCreationUtilities.CreateExtrusionGeometry(curveloop_1, n_normal_1, distance)
							solid_2 = DB.GeometryCreationUtilities.CreateExtrusionGeometry(curveloop_2, normal_2, distance)
							n_solid_2 = DB.GeometryCreationUtilities.CreateExtrusionGeometry(curveloop_2, n_normal_2, distance)
							face = self.boolean_intersection(solid_1, solid_2, normal_1)
							if face:
								area += face[0].Area * 0.092903
							else:
								face = self.boolean_intersection(n_solid_1, solid_2, normal_1)
								if face:
									area += face[0].Area * 0.092903
								else:
									face = self.boolean_intersection(solid_1, n_solid_2, normal_1)
									if face:
										area += face[0].Area * 0.092903
									else:
										face = self.boolean_intersection(n_solid_1, n_solid_2, normal_1)
										if face:
											area += face[0].Area * 0.092903
										else: 
											pass
			elif self.wall_1 == False and self.wall_2 == True and self.wall_3 == True:
				for geo_1 in geometry[1]:
					for geo_2 in geometry[2]:
						curveloop_1 = geo_1[2].GetEdgesAsCurveLoops()
						curveloop_2 = geo_2[2].GetEdgesAsCurveLoops()
						faces_1 = geo_1[0].Faces[0].GetSurface()
						faces_2 = geo_2[0].Faces[0].GetSurface()
						normal_1 = geo_1[1]
						n_normal_1 = normal_1.Negate()
						normal_2 = geo_2[1]
						n_normal_2 = normal_2.Negate()
						distance = 1
						solid_1 = DB.GeometryCreationUtilities.CreateExtrusionGeometry(curveloop_1, normal_1, distance)
						n_solid_1 = DB.GeometryCreationUtilities.CreateExtrusionGeometry(curveloop_1, n_normal_1, distance)
						solid_2 = DB.GeometryCreationUtilities.CreateExtrusionGeometry(curveloop_2, normal_2, distance)
						n_solid_2 = DB.GeometryCreationUtilities.CreateExtrusionGeometry(curveloop_2, n_normal_2, distance)
						face = self.boolean_intersection(solid_1, solid_2, normal_1)
						if face:
							area += face[0].Area * 0.092903
						else:
							face = self.boolean_intersection(n_solid_1, solid_2, normal_1)
							if face:
								area += face[0].Area * 0.092903
							else:
								face = self.boolean_intersection(solid_1, n_solid_2, normal_1)
								if face:
									area += face[0].Area * 0.092903
								else:
									face = self.boolean_intersection(n_solid_1, n_solid_2, normal_1)
									if face:
										area += face[0].Area * 0.092903
									else: 
										pass
			Alert("Площадь: {} кв.м.".format(str(round(area, 2))), title="KPLN Энергоэффективность", header = "Результат")
			self.Show()
		except Exception as e:
			forms.alert(str(e))
			self.Show()
			self.Close()
form = CreateWindow()
Application.Run(form)
