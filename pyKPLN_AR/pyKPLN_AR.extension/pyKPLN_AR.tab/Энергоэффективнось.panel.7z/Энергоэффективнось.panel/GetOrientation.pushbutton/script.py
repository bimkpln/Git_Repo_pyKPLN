# -*- coding: utf-8 -*-
"""
ElementsOrientation

"""
__author__ = 'Igor Perfilyev - envato.perfilev@gmail.com'
__title__ = "Ориентация\nокон"
__doc__ = 'description' \

"""
Архитекурное бюро KPLN

"""
import math
from pyrevit.framework import clr

# clr.AddReference("RevitNodes")

import re
from rpw import doc, uidoc, DB, UI, db, ui, revit
from pyrevit import script
from pyrevit import forms
from pyrevit import DB, UI
from pyrevit.revit import Transaction, selection
from System.Collections.Generic import *
from rpw.ui.forms import CommandLink, TaskDialog, Alert
import datetime
def logger(result):
	try:
		now = datetime.datetime.now()
		filename = "{}-{}-{}_{}-{}-{}_({})_Основа окон.txt".format(str(now.year), str(now.month), str(now.day), str(now.hour), str(now.minute), str(now.second), revit.username)
		file = open("Z:\\Отдел BIM\\Перфильев Игорь\\Отчеты_UNIs\\{}".format(filename), "w+")
		text = "unis report\nfile:{}\nversion:{}\nuser:{}\nresult:{};".format(doc.PathName, revit.version, revit.username, result)
		file.write(text.encode('utf-8'))
		file.close()
	except: pass

commands = [CommandLink('Да : С-Ю-З-В', return_value=1), CommandLink('Да : С-СВ-В-ЮВ-Ю-ЮЗ-З-СЗ', return_value=2), CommandLink('Отмена', return_value=False)]
dialog = TaskDialog('Рассчитать положение окон?',
					title = "Энергоэффективность",
					title_prefix=False,
					content="Текстовое значение запишется в автоматически подгруженный параметр «ЭЭ_Ориентация». Ориентирование элементов происходит относительно истинного севера проекта.",
					commands=commands,
					footer='См. Энергоэффективность (Notion.so)',
					show_close=False)
result = dialog.show()
if result != False:
	try:
		group = "АРХИТЕКТУРА - Дополнительные"
		global_param = "ЭЭ_Ориентация"
		room_params_type = "Text"
		param_found = False
		common_parameters_file = "Z:\\Отдел BIM\\02_Внутренняя документация\\05_ФОП\\ФОП2019_КП_АР.txt"
		app = doc.Application
		category_set_elements = app.Create.NewCategorySet()
		insert_cat_elements = doc.Settings.Categories.get_Item(DB.BuiltInCategory.OST_Windows)
		category_set_elements.Insert(insert_cat_elements)
		originalFile = app.SharedParametersFilename
		app.SharedParametersFilename = common_parameters_file
		SharedParametersFile = app.OpenSharedParameterFile()
		map = doc.ParameterBindings
		it = map.ForwardIterator()
		it.Reset()
		while it.MoveNext():
			d_Definition = it.Key
			d_Name = it.Key.Name
			d_Binding = it.Current
			d_catSet = d_Binding.Categories		
			if d_Name == global_param:
				if d_Binding.GetType() == DB.InstanceBinding:
					if str(d_Definition.ParameterType) == "Text":
						if d_Definition.VariesAcrossGroups:
							if d_catSet.Contains(DB.Category.GetCategory(doc, DB.BuiltInCategory.OST_Windows)):
								param_found == True
		with db.Transaction(name = "AddSharedParameter"):
			for dg in SharedParametersFile.Groups:
				if dg.Name == group:
					if not param_found:
						externalDefinition = dg.Definitions.get_Item(global_param)
						newIB = app.Create.NewInstanceBinding(category_set_elements)
						doc.ParameterBindings.Insert(externalDefinition, newIB, DB.BuiltInParameterGroup.PG_DATA)
						doc.ParameterBindings.ReInsert(externalDefinition, newIB, DB.BuiltInParameterGroup.PG_DATA)

		map = doc.ParameterBindings
		it = map.ForwardIterator()
		it.Reset()
		with db.Transaction(name = "SetAllowVaryBetweenGroups"):
			while it.MoveNext():
				if not param_found:
					d_Definition = it.Key
					d_Name = it.Key.Name
					d_Binding = it.Current
					if d_Name == global_param:
						d_Definition.SetAllowVaryBetweenGroups(doc, True)
	except: pass

	collector_elements = DB.FilteredElementCollector(doc).OfClass(DB.FamilyInstance).OfCategory(DB.BuiltInCategory.OST_Windows)
	collector_basepoint = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_ProjectBasePoint)
	counter = 0
	collect = []
	for element in collector_basepoint:
		basepoint = element
		degree = basepoint.get_Parameter(DB.BuiltInParameter.BASEPOINT_ANGLETON_PARAM).AsDouble()
	with db.Transaction(name = "Write value"):
		for element in collector_elements:
			name = element.Symbol.FamilyName
			orient = element.FacingOrientation
			angle = math.atan(orient.X/orient.Y) / 0.01745329251994
			if orient.Y >= 0.000000 and orient.X >= 0.000000:
				trueangle = angle
				collect.append([element, trueangle])
			elif orient.X >= 0.000000:
				trueangle = angle + 180
				collect.append([element, trueangle])
			elif orient.Y >= 0.000000:
				trueangle = angle + +360
				collect.append([element, trueangle])
			else:
				trueangle = angle + 180
				collect.append([element, trueangle])
		for i in collect:
			angle_write = i[1] + degree / 0.01745329251994
			if angle_write > 360:
				angle_write -= 360
			angle_text = ""
			if result == 1:
				if angle_write >= 315 or angle_write < 45:
					angle_text = "С"
				elif angle_write >= 45 and angle_write < 135:
					angle_text = "В"
				elif angle_write >= 135 and angle_write < 225:
					angle_text = "Ю"
				elif angle_write >= 225 and angle_write < 315:
					angle_text = "З"
			if result == 2:
				if angle_write >= 337.5 or angle_write < 22.5:
					angle_text = "С"
				elif angle_write >= 22.5 and angle_write < 67.5:
					angle_text = "С-В"
				elif angle_write >= 67.5 and angle_write < 112.5:
					angle_text = "В"
				elif angle_write >= 112.5 and angle_write < 157.5:
					angle_text = "Ю-В"
				elif angle_write >= 157.5 and angle_write < 202.5:
					angle_text = "Ю"
				elif angle_write >= 202.5 and angle_write < 247.5:
					angle_text = "Ю-З"
				elif angle_write >= 247.5 and angle_write < 292.5:
					angle_text = "З"
				elif angle_write >= 292.5 and angle_write < 337.5:
					angle_text = "С-З"
			par = i[0].LookupParameter(global_param)
			par.Set(angle_text)