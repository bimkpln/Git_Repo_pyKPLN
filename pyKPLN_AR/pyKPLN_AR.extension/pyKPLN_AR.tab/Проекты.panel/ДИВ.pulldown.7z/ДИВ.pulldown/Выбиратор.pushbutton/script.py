# -*- coding: utf-8 -*-
"""
KPLN:DIV:SELECTOR

"""
__author__ = 'Igor Perfilyev - envato.perfilev@gmail.com'
__title__ = "Выбрать + Заполнить"
__doc__ = 'Заполнить параметры выбранных элементов. Инструмент позволяет быстро выбирать элементы, для выбора которым необходимо использовать клавишу TAB' \

"""
Архитекурное бюро KPLN

"""
import math
from pyrevit.framework import clr

import wpf
from System.Windows import Application, Window
from System.Collections.ObjectModel import ObservableCollection

import re
import System
from rpw import doc, uidoc, DB, UI, db, ui, revit
from pyrevit import script
from pyrevit import forms
from pyrevit import DB, UI
from pyrevit.revit import Transaction, selection
from System.Collections.Generic import *
from rpw.ui.forms import CommandLink, TaskDialog, Alert
import datetime
import webbrowser

class WPFCategory():
	def __init__(self, category):
		self.IsChecked = False
		self.Category = category

class MassSelectorFilter (UI.Selection.ISelectionFilter):
	def AllowElement(self, element = DB.Element):
		if element.Category.Id.IntegerValue != -2000095:
			return True
		else:
			return False
	def AllowReference(self, refer, point):
		return False

class ParametersForm(Window):
	def __init__(self, parameters):
		wpf.LoadComponent(self, 'Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\Проекты.panel\\ДИВ.pulldown\\Выбиратор (формы).pushbutton\\Parameters.xaml')
		self.cbxParameters.ItemsSource = parameters

	def OnBtnApply(self, sender, e):
		global pickedParameter
		global pickedValue
		pickedParameter = self.cbxParameters.SelectedItem
		pickedValue = self.tbxValue.Text
		self.Close()

def PickElement():
	elements = []
	try:
		pick_filter = MassSelectorFilter()
		ref_elements = uidoc.Selection.PickObjects(UI.Selection.ObjectType.Element, pick_filter, "Выберите элементы кроме : <Группы модели>")
		for i in ref_elements:
			try:
				elements.append(doc.GetElement(i))
			except: pass
	except:
	    pass
	return elements

def GetGeometry(element):
	solids = []
	if element.Category.Id.IntegerValue == -2000160:
		SpatialElementBoundaryLocation = DB.SpatialElementBoundaryLocation.Finish
		calculator = DB.SpatialElementGeometryCalculator(doc, DB.SpatialElementBoundaryOptions())
		results = calculator.CalculateSpatialElementGeometry(element)
		room_solid = results.GetGeometry()
		if room_solid != None:
			solids.append(room_solid)
	else:
		options = DB.Options()
		options.DetailLevel = DB.ViewDetailLevel.Fine
		options.IncludeNonVisibleObjects = True
		for i in element.get_Geometry(options):
			try:
				if type(i) == DB.Solid:
					if i.SurfaceArea != 0:
						solids.append(i)
			except: pass
			try:
				for g in i.GetInstanceGeometry():
					if type(g) == DB.Solid:
						if g.SurfaceArea != 0:
							solids.append(g)
			except: pass
	return solids

cats = []
pickedElements = PickElement()
if len(pickedElements) > 0:
	params = []
	hash = []
	for i in pickedElements:
		for j in i.Parameters:
			if j.StorageType == DB.StorageType.String and not j.Definition.Name in hash:
				params.append(j)
				hash.append(j.Definition.Name)
	params.sort(key=lambda x: x.Definition.Name, reverse=False)
	pickedParameter = None
	pickedValue = None
	ParametersForm(params).ShowDialog()
	if pickedParameter != None and pickedValue != None:
		with db.Transaction(name = "Запись в параметр"):
			for i in pickedElements:
				try:
					for j in i.Parameters:
						if j.IsShared == pickedParameter.IsShared and j.Definition.Name == pickedParameter.Definition.Name and j.StorageType == DB.StorageType.String:
							j.Set(pickedValue)
				except :
					pass