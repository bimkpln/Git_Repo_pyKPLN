# -*- coding: utf-8 -*-
"""
TaskOpenPlacer

"""
__author__ = 'Igor Perfilyev - envato.perfilev@gmail.com'
__title__ = "Расставить\nзадания"
__doc__ = 'Расстановка заданий на отверстия по пересечениям с\nподгружеными файлами АР/КР\n\nС формированием html-отчета и выводом на печать' \

"""
Архитекурное бюро KPLN

"""
import math
import os
import System
from pyrevit.framework import clr
import re
from rpw import doc, uidoc, DB, UI, db, ui, revit as Revit
from pyrevit import script
from pyrevit import forms
from pyrevit import revit, DB, UI
from pyrevit.revit import Transaction, selection
from System.Collections.Generic import *
import datetime
from System.Windows.Forms import *
from System.Drawing import *
from rpw.ui.forms import CommandLink, TaskDialog, Alert
from System import Guid

class CheckValueSingle(Form):
	def __init__(self, element):
		self.TopMost = True
		self.label = Label()
		self.label.Parent = self

		self.label.AutoSize = True
		self.label.Location = Point(3, 2)
		self.label.Size = Size(93, 13)
		self.label.Text = "Отверстия: {}hx{} : ?x?".format(str(int((element.LookupParameter("Высота").AsDouble() + element.LookupParameter("Расширение границ").AsDouble()*2) * 304.8)), str(int((element.LookupParameter("Ширина").AsDouble() + element.LookupParameter("Расширение границ").AsDouble()*2) * 304.8)))
		self.label.TextAlign = System.Drawing.ContentAlignment.MiddleRight

		self.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		self.ClientSize = Size(204, 107)
		self.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
		self.Name = "Определение расстояния : ?"
		self.Text = "Определение расстояния : ?"
		self.CenterToScreen()

class CheckValueTuple(Form):
	def __init__(self, elements):
		self.TopMost = True
		points = []
		offsets = []
		for element in elements:
			points.append(element.Location.Point)
			offsets.append(element.get_Parameter(DB.BuiltInParameter.INSTANCE_ELEVATION_PARAM).AsDouble())
		x_1 = points[0].X
		x_2 = points[1].X
		y_1 = points[0].Y
		y_2 = points[1].Y
		z_1 = points[0].Z + offsets[0]
		z_2 = points[1].Z + offsets[1]
		l_h = self.GetLength(DB.XYZ(x_1, y_1, 0), DB.XYZ(x_2, y_2, 0))
		l_v = self.GetLength(DB.XYZ(0, 0, z_1), DB.XYZ(0, 0, z_2))
		l_d = self.GetLength(DB.XYZ(x_1, y_1, z_1), DB.XYZ(x_2, y_2, z_2))
		self.H = str(round(l_h * 304.8, 2)) + "мм"
		self.V = str(round(l_v * 304.8, 2)) + "мм"
		self.D = str(round(l_d * 304.8, 2)) + "мм"

		self.label = Label()
		self.label.Parent = self
		self.label_min_h = Label()
		self.label_min_h.Parent = self
		self.label_min_v = Label()
		self.label_min_v.Parent = self
		self.min_v = Label()
		self.min_v.Parent = self
		self.min_h = Label()
		self.min_h.Parent = self
		self.label_grid = Label()
		self.label_grid.Parent = self
		self.grid = Label()
		self.grid.Parent = self

		self.label.AutoSize = True
		self.label.Location = Point(3, 2)
		self.label.Size = Size(93, 13)
		self.label.Text = "Отверстия: {}hx{} : {}hx{}".format(str(int((elements[0].LookupParameter("Высота").AsDouble() + elements[0].LookupParameter("Расширение границ").AsDouble()*2) * 304.8)), str(int((elements[0].LookupParameter("Ширина").AsDouble() + elements[0].LookupParameter("Расширение границ").AsDouble()*2) * 304.8)), str(int((elements[1].LookupParameter("Высота").AsDouble() + elements[1].LookupParameter("Расширение границ").AsDouble()*2) * 304.8)), str(int((elements[1].LookupParameter("Ширина").AsDouble() + elements[1].LookupParameter("Расширение границ").AsDouble()*2) * 304.8)))
		self.label.TextAlign = System.Drawing.ContentAlignment.MiddleRight

		self.label_min_h.AutoSize = True
		self.label_min_h.Location = Point(30, 18)
		self.label_min_h.Size = Size(93, 13)
		self.label_min_h.Text = "Расстояние V:"
		self.label_min_h.TextAlign = System.Drawing.ContentAlignment.MiddleRight

		self.label_min_v.AutoSize = True
		self.label_min_v.Location = Point(30, 43)
		self.label_min_v.Size = Size(96, 13)
		self.label_min_v.Text = "Расстояние H:"
		self.label_min_v.TextAlign = System.Drawing.ContentAlignment.MiddleRight

		self.label_grid.AutoSize = True
		self.label_grid.Location = Point(30, 70)
		self.label_grid.Size = Size(109, 13)
		self.label_grid.Text = "Расстояние D:"
		self.label_grid.TextAlign = System.Drawing.ContentAlignment.MiddleRight

		self.min_v.AutoSize = True
		self.min_v.Location = Point(127, 43)
		self.min_v.Size = Size(56, 13)
		self.min_v.Text = self.V
		self.min_v.TextAlign = System.Drawing.ContentAlignment.MiddleLeft

		self.min_h.AutoSize = True
		self.min_h.Location = Point(127, 18)
		self.min_h.Size = Size(56, 13)
		self.min_h.Text = self.H
		self.min_h.TextAlign = System.Drawing.ContentAlignment.MiddleLeft

		self.grid.AutoSize = True
		self.grid.Location = Point(127, 70)
		self.grid.Size = Size(56, 13)
		self.grid.Text = self.D
		self.grid.TextAlign = System.Drawing.ContentAlignment.MiddleLeft

		self.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		self.ClientSize = Size(204, 107)
		self.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
		self.Name = "Определение расстояния"
		self.Text = "Определение расстояния"
		self.CenterToScreen()

	def GetLength(self, pt_1, pt_2):
		d_x = pt_1.X - pt_2.X
		d_y = pt_1.Y - pt_2.Y
		d_z = pt_1.Z - pt_2.Z
		return math.sqrt(d_x*d_x + d_y*d_y + d_z*d_z)

class OpeningsSelectorFilterRectangle (UI.Selection.ISelectionFilter):
	def _init_(self):
		self.list = []

	def SetList(self, list):
		self.list = list

	def InList(self, element):
		for i in self.list:
			try:
				if i.Id.ToString() == element.Id.ToString():
					return True
			except: pass
		return False

	def AllowElement(self, element = DB.Element):
		if self.InList(element) and element.Category.Id == DB.ElementId(-2001140) and ("501_задание на отверстие в стене прямоугольное" in str(element.Symbol.FamilyName).lower() or "501_задание на отверстие в стене прямоугольное" in str(element.Name).lower()):
			return True
		return False
	def AllowReference(self, refer, point):
		return False

class OpeningsSelectorFilterRound (UI.Selection.ISelectionFilter):
	def _init_(self):
		self.list = []

	def SetList(self, list):
		self.list = list

	def InList(self, element):
		for i in self.list:
			try:
				if i.Id.ToString() == element.Id.ToString():
					return True
			except: pass
		return False

	def AllowElement(self, element = DB.Element):
		if self.InList(element) and element.Category.Id == DB.ElementId(-2001140) and ("501_задание на отверстие в стене круглое" in str(element.Symbol.FamilyName).lower() or "501_задание на отверстие в стене круглое" in str(element.Name).lower()):
			return True
		return False
	def AllowReference(self, refer, point):
		return False

class OpeningsSelectorFilter (UI.Selection.ISelectionFilter):
	def _init_(self):
		self.list = []

	def SetList(self, list):
		self.list = list

	def InList(self, element):
		for i in self.list:
			try:
				if i.Id.ToString() == element.Id.ToString():
					return True
			except: pass
		return False

	def AllowElement(self, element = DB.Element):
		if self.InList(element) and element.Category.Id == DB.ElementId(-2001140) and ("501_задание на отверстие в стене круглое" in str(element.Symbol.FamilyName).lower() or "501_задание на отверстие в стене круглое" in str(element.Name).lower() or "501_задание на отверстие в стене прямоугольное" in str(element.Symbol.FamilyName).lower() or "501_задание на отверстие в стене прямоугольное" in str(element.Name).lower()):
			return True
		return False
	def AllowReference(self, refer, point):
		return False

class Asset():
	def __init__(self, task, wallset, element):
		self.Task = []
		self.Wallset = wallset
		self.Element = element
		if type(task) is list:
			for i in range(0, len(task)): 
				self.Task.append(task[i])
		else:
			self.Task.append(task)

	def ContainsId(self, id):
		if self.Element.Id.ToString() == id.ToString():
			return True
		else:
			return False

	def IsGroup(self):
		if len(self.Task) > 1:
			return True
		else: return False

	def Remove(self):
		with db.Transaction(name = "RemoveElement"):
			try:
				doc.Delete(self.Element.Id)
				self.Element = None
			except: pass

	def SetElement(self, element):
		self.Element = element

	@property
	def Task(self):
		return self.Task

	@property
	def Wallset(self):
		return self.Wallset

	@property
	def Element(self):
		return self.Element

class WallSet():
	def __init__(self, wall, solid, centroid, bbox, curve):
		self.Wall = wall
		self.Solid = solid
		self.Centroid = centroid
		self.BoundingBox = bbox
		self.Curve = curve

	@property
	def Wall(self):
		return self.Wall
	@property
	def Solid(self):
		return self.Solid
	@property
	def Centroid(self):
		return self.Centroid
	@property
	def BoundingBox(self):
		return self.BoundingBox
	@property
	def Curve(self):
		return self.Curve

class Matrix():
	def __init__(self, BoundingBox):
		self.matrix = []
		self.minx = BoundingBox.Min.X
		self.maxx = BoundingBox.Max.X
		self.miny = BoundingBox.Min.Y
		self.maxy = BoundingBox.Max.Y
		self.minz = BoundingBox.Min.Z
		self.maxz = BoundingBox.Max.Z
		for x in range(int(self.minx), int(self.maxx)):
			for y in range(int(self.miny), int(self.maxy)):
				for z in range(int(self.minz), int(self.maxz)):
					matrix_1 = []
					Box_1 = DB.BoundingBoxXYZ()
					Box_1.Min = DB.XYZ(40 * x, 40 * y, 40 * z)
					Box_1.Max = DB.XYZ(40 * x + 40, 40 * y + 40, 40 * z + 40)
					boxes_1 = self.ExplodeBBox(Box_1)
					for Box_2 in boxes_1:
						boxes_2 = self.ExplodeBBox(Box_2)
						matrix_2 = []
						for b in boxes_2:
							matrix_2.append([b, []])
						matrix_1.append([Box_2, matrix_2])
					self.matrix.append([Box_1, matrix_1])

	def Flatten(self):
		try:
			op_matrix = []
			for matrix in self.matrix:
				m2 = []
				for matrix_1 in matrix[1]:
					m3 = []
					for matrix_2 in matrix_1[1]:
						if len(matrix_2[1]) != 0:
							m3.append(matrix_2)
					if len(m3) != 0:
						m2.append([matrix_1[0], m3])
				if len(m2) != 0:
					op_matrix.append([matrix[0], m2])
			self.matrix = []
			for i in op_matrix:
				self.matrix.append(i)
			return True
		except: return False

	def BboxIntersect(self, Box_1, Box_2):
		try:
			if Box_2.Max.Z < Box_1.Min.Z or Box_2.Min.Z > Box_1.Max.Z:
				return False
			if Box_2.Max.Y < Box_1.Min.Y or Box_2.Min.Y > Box_1.Max.Y:
				return False
			if Box_2.Max.X < Box_1.Min.X or Box_2.Min.X > Box_1.Max.X:
				return False
			return True
		except: return False

	def Insert(self, task):
		for i in self.matrix:
			box_1 = i[0]
			if self.BboxIntersect(task.BoundingBox, i[0]):
				for z in i[1]:
					box_2 = z[0]
					if self.BboxIntersect(task.BoundingBox, z[0]):
						for x in z[1]:
							if self.BboxIntersect(task.BoundingBox, x[0]):
								x[1].append(task)
		return True

	def TaskIsUniq(self, Task, list):
		try:
			if len(list) == 0:
				return True
			for i in list:
				if str(i.Element.Id) == str(Task.Element.Id):
					return False
			return True
		except: return False

	def GetInserts(self, box):
		list = []
		min_z = box.Min.Z
		max_z = box.Max.Z
		min_y = box.Min.Y
		max_y = box.Max.Y
		min_x = box.Min.X
		max_x = box.Max.X
		for i in self.matrix:
			box_1 = i[0]
			if max_z < box_1.Min.Z or min_z > box_1.Max.Z:
				continue
			if max_y < box_1.Min.Y or min_y > box_1.Max.Y:
				continue
			if max_x < box_1.Min.X or min_x > box_1.Max.X:
				continue
			for z in i[1]:
				box_2 = z[0]
				if max_z < box_2.Min.Z or min_z > box_2.Max.Z:
					continue
				if max_y < box_2.Min.Y or min_y > box_2.Max.Y:
					continue
				if max_x < box_2.Min.X or min_x > box_2.Max.X:
					continue
				for x in z[1]:
					box_3 = x[0]
					if max_z < box_3.Min.Z or min_z > box_3.Max.Z:
						continue
					if max_y < box_3.Min.Y or min_y > box_3.Max.Y:
						continue
					if max_x < box_3.Min.X or min_x > box_3.Max.X:
						continue
					for task in x[1]:
						if self.TaskIsUniq(task, list):
							list.append(task)
		return list

	def ExplodeBBox(self, boundingbox):
		min = boundingbox.Min
		max = boundingbox.Max
		w = math.fabs(max.X - min.X)
		bbox_mini_1 = DB.BoundingBoxXYZ()
		bbox_mini_1.Min = DB.XYZ(min.X, min.Y, min.Z)
		bbox_mini_1.Max = DB.XYZ(min.X + w, min.Y + w, min.Z + w)

		bbox_mini_2 = DB.BoundingBoxXYZ()
		bbox_mini_2.Min = DB.XYZ(min.X + w, min.Y, min.Z)
		bbox_mini_2.Max = DB.XYZ(min.X + 2 * w, min.Y + w, min.Z + w)

		bbox_mini_3 = DB.BoundingBoxXYZ()
		bbox_mini_3.Min = DB.XYZ(min.X, min.Y + w, min.Z)
		bbox_mini_3.Max = DB.XYZ(min.X + w, min.Y + 2 * w, min.Z + w)

		bbox_mini_4 = DB.BoundingBoxXYZ()
		bbox_mini_4.Min = DB.XYZ(min.X + w, min.Y + w, min.Z)
		bbox_mini_4.Max = DB.XYZ(min.X + 2 * w, min.Y + 2 * w, min.Z + w)

		bbox_mini_5 = DB.BoundingBoxXYZ()
		bbox_mini_5.Min = DB.XYZ(min.X, min.Y, min.Z + w)
		bbox_mini_5.Max = DB.XYZ(min.X + w, min.Y + w, min.Z + 2 * w)

		bbox_mini_6 = DB.BoundingBoxXYZ()
		bbox_mini_6.Min = DB.XYZ(min.X + w, min.Y, min.Z + w)
		bbox_mini_6.Max = DB.XYZ(min.X + 2 * w, min.Y + w, min.Z + 2 * w)

		bbox_mini_7 = DB.BoundingBoxXYZ()
		bbox_mini_7.Min = DB.XYZ(min.X, min.Y + w, min.Z + w)
		bbox_mini_7.Max = DB.XYZ(min.X + w, min.Y + 2 * w, min.Z + 2 * w)

		bbox_mini_8 = DB.BoundingBoxXYZ()
		bbox_mini_8.Min = DB.XYZ(min.X + w, min.Y + w, min.Z + w)
		bbox_mini_8.Max = DB.XYZ(min.X + 2 * w, min.Y + 2 * w, min.Z + 2 * w)

		return [bbox_mini_1, bbox_mini_2, bbox_mini_3, bbox_mini_4, bbox_mini_5, bbox_mini_6, bbox_mini_7, bbox_mini_8]

class TaskElement():
	def __init__(self, element, bbox, centroid, solid):
		self.Element = element
		self.BoundingBox = bbox
		self.Centroid = centroid
		self.Solid = solid
		self.Intersection = None

	def SetIntersection(self, s):
		self.Intersection = s

	@property
	def Intersection(self):
		return self.Intersection

	@property
	def Element(self):
		return self.Element

	@property
	def BoundingBox(self):
		return self.BoundingBox

	@property
	def Centroid(self):
		return self.Centroid

	@property
	def Solid(self):
		return self.Solid

class ChoseFilter(Form):
	def __init__(self):
		global linked_document
		global g_workset
		global sys_type
		global result
		#INIT
		self.Name = "KPLN_SYS_Openings"
		self.Text = "KPLN : Задания на отверстия"
		self.Size = Size(350, 300)
		self.MinimumSize = Size(350, 300)
		self.MaximumSize = Size(350, 300)
		self.MaximizeBox = False
		self.MinimizeBox = False
		self.ControlBox = True
		self.FormBorderStyle = FormBorderStyle.FixedToolWindow
		self.TopMost = True
		self.Icon = Icon("Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\icon.ico")
		self.element_parameters = []
		self.elementtype_parameters = []
		self.elements = []

		self.worksets = []
		for workset in DB.FilteredWorksetCollector(doc).OfKind(DB.WorksetKind.UserWorkset).ToWorksets():
			self.worksets.append(workset.Name)
		self.documents = []
		for link in DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_RvtLinks).WhereElementIsNotElementType().ToElements():
			try:
				document = link.GetLinkDocument()
				self.documents.append(document.Title)
			except:
				forms.alert("Файл «{}.rvt» выгружен из проекта и не может участвовать в расчете!".format(link.Name.split(".rvt")[0]))
		self.label_description = Label()
		self.label_description.Parent = self
		self.label_description.AutoSize = False
		self.label_description.Location = Point(12, 9)
		self.label_description.Size = Size(304, 49)
		self.label_description.Text = "Задайте настройки для проведения расчета. Все системы должны быть разделены по рабочим наборам. Расчет необходимо проводить на основе файла КР."

		self.gb = GroupBox()
		self.gb.Parent = self
		self.gb.Text = "Настройки"
		self.gb.Size = Size(310, 158)
		self.gb.Location = Point(12, 61)

		self.comboBox1 = ComboBox()
		self.comboBox1.Parent = self.gb
		self.comboBox1.Location = Point(6, 32)
		self.comboBox1.Size = Size(298, 21)
		self.comboBox1.DropDownStyle = ComboBoxStyle.DropDownList
		for item in ["ОВ", "ВК", "ЭОМ", "СС", "АУПТ"]:
			self.comboBox1.Items.Add(item)
		self.comboBox1.SelectedIndexChanged += self.CblOnChanged

		self.comboBox2 = ComboBox()
		self.comboBox2.Parent = self.gb
		self.comboBox2.Location = Point(6, 81)
		self.comboBox2.Size = Size(298, 21)
		self.comboBox2.DropDownStyle = ComboBoxStyle.DropDownList
		self.comboBox2.Items.Add("<все рабочие наборы>")
		for item in self.worksets:
			self.comboBox2.Items.Add(item)
		self.comboBox2.SelectedIndexChanged += self.CblOnChanged

		self.comboBox3 = ComboBox()
		self.comboBox3.Parent = self.gb
		self.comboBox3.Location = Point(6, 130)
		self.comboBox3.Size = Size(298, 21)
		self.comboBox3.DropDownStyle = ComboBoxStyle.DropDownList
		for item in self.documents:
			self.comboBox3.Items.Add(item)
		self.comboBox3.SelectedIndexChanged += self.CblOnChanged

		self.label1 = Label()
		self.label1.Parent = self.gb
		self.label1.AutoSize = True
		self.label1.Location = Point(6, 16)
		self.label1.Text = "Выберите свой раздел:"

		self.label2 = Label()
		self.label2.Parent = self.gb
		self.label2.AutoSize = True
		self.label2.Location = Point(6, 65)
		self.label2.Text = "Выберите рабочий набор системы:"

		self.label3 = Label()
		self.label3.Parent = self.gb
		self.label3.AutoSize = True
		self.label3.Location = Point(6, 114)
		self.label3.Text = "Расчитываемый файл:"

		self.ok = Button(Text = "Применить")
		self.ok.Parent = self
		self.ok.Location = Point(12, 232)
		self.ok.Click += self.OnOk
		self.ok.Enabled = False

		self.cancel = Button(Text = "Отмена")
		self.cancel.Parent = self
		self.cancel.Location = Point(93, 232)
		self.cancel.Click += self.OnCancel

		self.comboBox2.Text = "<все рабочие наборы>"

		self.CenterToScreen()

	def OnCancel(self, sender, args):
		global result
		result = "cancel"
		self.Close()

	def OnOk(self, sender, args):
		global sys_type
		global linked_document
		global g_workset
		for link in DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_RvtLinks).WhereElementIsNotElementType().ToElements():
			try:
				document = link.GetLinkDocument()
				if document.Title == self.comboBox3.Text:
					linked_document = document
					break
			except:
				pass
		if self.comboBox2.Text == "<все рабочие наборы>":
			g_workset = "<все рабочие наборы>"
		else:
			for workset in DB.FilteredWorksetCollector(doc).OfKind(DB.WorksetKind.UserWorkset).ToWorksets():
				if workset.Name == self.comboBox2.Text:
					g_workset = workset
					break
		sys_type = self.comboBox1.Text
		self.Close()

	def CblOnChanged(self, sender, event):
		if self.comboBox1.Text != "" and self.comboBox2.Text != "" and self.comboBox3.Text != "":
			self.ok.Enabled = True
		else:
			self.ok.Enabled = False

class RunParser(Form):
	def __init__(self):
		global walls
		global family_symbol
		global linked_document
		global g_workset
		self.Name = "KPLN_SYS_Openings"
		self.Text = "KPLN Задание на отверстия"
		self.Size = Size(600, 420)
		self.MinimumSize = Size(600, 420)
		self.MaximumSize = Size(600, 420)
		self.MaximizeBox = False
		self.MinimizeBox = False
		self.ControlBox = False
		self.FormBorderStyle = FormBorderStyle.FixedDialog
		self.TopMost = True
		self.Icon = Icon("Z:\\pyRevit\\pyKPLN_AR (alpha)\\pyKPLN_AR.extension\\pyKPLN_AR.tab\\icon.ico")

		self.active_image = None
		self.active_wall = None
		self.created_elements = []
		self.created_elements_post = []
		self.assets = []
		self.walls = []
		self.tasks = []
		self.step = 0

		self.elements = []
		self.elements_curves = []
		self.elements_intersection = []

		self.output = script.get_output()
		self.output.set_title("KPLN : Отчет по расстановке отверстий (заданий)")
		self.report_succeeded = []
		self.report_failures = []

		self.gb1 = GroupBox()
		self.gb2 = GroupBox()
		self.button1 = Button()
		self.button2 = Button()
		self.button3 = Button()
		self.button4 = Button()
		self.button5 = Button()
		self.button6 = Button()
		self.button7 = Button()
		self.button8 = Button()
		self.button9 = Button()
		self.button10 = Button()
		self.button11 = Button()
		self.button12 = Button()
		self.button13 = Button()
		self.button14 = Button()

		self.ImageBox = PictureBox()
		self.ImageBox.Parent = self.gb1
		self.Separator = Image.FromFile('Z:\\pyRevit\\pyKPLN_MEP\\KPLN.extension\\pyKPLN_MEP.tab\\Отверстия.panel\\Separator.png')
		self.ImageBox.Size = Size(self.Separator.Width, self.Separator.Height)
		self.ImageBox.Location = Point(119, 19)
		self.ImageBox.Image = self.Separator

		self.ttip_group = ToolTip()
		self.ttip_group.SetToolTip(self.button1, "Сгруппировать отверстия в одно (большое) отверстие")
		self.ttip_group.ToolTipTitle = "Сгруппировать отверстия"

		self.ttip_ungroup = ToolTip()
		self.ttip_ungroup.SetToolTip(self.button2, "Взорвать (сгруппированное) отверстие\nна отдельные отверстия")
		self.ttip_ungroup.ToolTipTitle = "Разгруппировать отверстия"

		self.ttip_remove = ToolTip()
		self.ttip_remove.SetToolTip(self.button3, "Удалить выбранное отверстие")
		self.ttip_remove.ToolTipTitle = "Удалить"

		self.ttip_offset = ToolTip()
		self.ttip_offset.SetToolTip(self.button10, "Задать увеличение по ширине и высоте для выбранного отверстия")
		self.ttip_offset.ToolTipTitle = "Задать смещение"

		self.ttip_offsetall = ToolTip()
		self.ttip_offsetall.SetToolTip(self.button11, "Задать увеличение по ширине и высоте для всех отверстий")
		self.ttip_offsetall.ToolTipTitle = "Задать смещение (для всех)"

		self.ttip_ruler = ToolTip()
		self.ttip_ruler.SetToolTip(self.button13, "Инструмент позволяет измерить расстояние от одного\nотверстия до другого и узнать размер отверстия")
		self.ttip_ruler.ToolTipTitle = "Измерить расстояние"

		self.ttip_swap = ToolTip()
		self.ttip_swap.SetToolTip(self.button12, "Замена типа отверстия с прямоугольного на круглое\nи обратно (не работает со сгруппированными отверстиями)")
		self.ttip_swap.ToolTipTitle = "Сделать круглым (квадратным)"

		self.ttip_refresh = ToolTip()
		self.ttip_refresh.SetToolTip(self.button14, "Обновление предварительного эскиза")
		self.ttip_refresh.SetToolTip(self.button9, "Обновление предварительного эскиза")
		self.ttip_refresh.ToolTipTitle = "Обновить"

		self.label1 = Label()
		self.richTextBox1 = RichTextBox()
		self.pb = PictureBox()
		self.pb.SizeMode = PictureBoxSizeMode.Zoom
		self.pb.BackColor =  System.Drawing.Color.FromArgb(255, 255,255,255)

		self.gb1.Location = Point(12, 214)
		self.gb1.Size = Size(275, 133)
		self.gb1.Text = "Действия"
		self.gb1.Parent = self

		self.gb2.Location = Point(297, 214)
		self.gb2.Size = Size(275, 133)
		self.gb2.Text = "Добавить в отчет"
		self.gb2.Parent = self

		self.button1.Location = Point(6, 19)
		self.button1.Size = Size(50, 50)
		self.button1.Text = ""
		self.button1.Parent = self.gb1
		self.button1.Click += self.JoinElements
		self.button1.FlatStyle = FlatStyle.Popup
		self.button1.Image = Image.FromFile('Z:\\pyRevit\\pyKPLN_MEP\\KPLN.extension\\pyKPLN_MEP.tab\\Отверстия.panel\\Group.png')
		self.button1.TextImageRelation = TextImageRelation.ImageBeforeText
		self.button1.MouseEnter += self.GIFEnter
		self.button1.MouseLeave += self.PNGLeave

		self.button2.Location = Point(62, 19)
		self.button2.Size = Size(50, 50)
		self.button2.Text = ""
		self.button2.Parent = self.gb1
		self.button2.Click += self.UnjoinElements
		self.button2.FlatStyle = FlatStyle.Popup
		self.button2.Image = Image.FromFile('Z:\\pyRevit\\pyKPLN_MEP\\KPLN.extension\\pyKPLN_MEP.tab\\Отверстия.panel\\Ungroup.png')
		self.button2.TextImageRelation = TextImageRelation.ImageBeforeText
		self.button2.MouseEnter += self.GIFEnter
		self.button2.MouseLeave += self.PNGLeave

		self.button3.Location = Point(219, 19)
		self.button3.Size = Size(50, 50)
		self.button3.Text = ""
		self.button3.Parent = self.gb1
		self.button3.Click += self.RemoveElements
		self.button3.FlatStyle = FlatStyle.Popup
		self.button3.Image = Image.FromFile('Z:\\pyRevit\\pyKPLN_MEP\\KPLN.extension\\pyKPLN_MEP.tab\\Отверстия.panel\\Remove.png')
		self.button3.TextImageRelation = TextImageRelation.ImageBeforeText
		self.button3.MouseEnter += self.GIFEnter
		self.button3.MouseLeave += self.PNGLeave

		self.button10.Location = Point(6, 75)
		self.button10.Size = Size(50, 50)
		self.button10.Text = ""
		self.button10.Parent = self.gb1
		self.button10.Click += self.SetOffsets
		self.button10.FlatStyle = FlatStyle.Popup
		self.button10.Image = Image.FromFile('Z:\\pyRevit\\pyKPLN_MEP\\KPLN.extension\\pyKPLN_MEP.tab\\Отверстия.panel\\Offset.png')
		self.button10.TextImageRelation = TextImageRelation.ImageBeforeText
		self.button10.MouseEnter += self.GIFEnter
		self.button10.MouseLeave += self.PNGLeave

		self.button11.Location = Point(62, 75)
		self.button11.Size = Size(50, 50)
		self.button11.Text = ""
		self.button11.Parent = self.gb1
		self.button11.Click += self.SetOffsetsToAll
		self.button11.FlatStyle = FlatStyle.Popup
		self.button11.Image = Image.FromFile('Z:\\pyRevit\\pyKPLN_MEP\\KPLN.extension\\pyKPLN_MEP.tab\\Отверстия.panel\\OffsetAll.png')
		self.button11.TextImageRelation = TextImageRelation.ImageBeforeText
		self.button11.MouseEnter += self.GIFEnter
		self.button11.MouseLeave += self.PNGLeave

		self.button12.Location = Point(163, 19)
		self.button12.Size = Size(50, 50)
		self.button12.Text = ""
		self.button12.Parent = self.gb1
		self.button12.Click += self.ChangeType
		self.button12.FlatStyle = FlatStyle.Popup
		self.button12.Image = Image.FromFile('Z:\\pyRevit\\pyKPLN_MEP\\KPLN.extension\\pyKPLN_MEP.tab\\Отверстия.panel\\RoundRectangle.png')
		self.button12.TextImageRelation = TextImageRelation.ImageBeforeText
		self.button12.MouseEnter += self.GIFEnter
		self.button12.MouseLeave += self.PNGLeave

		self.button13.Location = Point(163, 75)
		self.button13.Size = Size(50, 50)
		self.button13.Text = ""
		self.button13.Parent = self.gb1
		self.button13.Click += self.CheckDistance
		self.button13.FlatStyle = FlatStyle.Popup
		self.button13.Image = Image.FromFile('Z:\\pyRevit\\pyKPLN_MEP\\KPLN.extension\\pyKPLN_MEP.tab\\Отверстия.panel\\Ruler.png')
		self.button13.TextImageRelation = TextImageRelation.ImageBeforeText
		self.button13.MouseEnter += self.GIFEnter
		self.button13.MouseLeave += self.PNGLeave

		self.button14.Location = Point(219, 75)
		self.button14.Size = Size(50, 50)
		self.button14.Text = ""
		self.button14.Parent = self.gb1
		self.button14.Click += self.Refresh
		self.button14.FlatStyle = FlatStyle.Popup
		self.button14.Image = Image.FromFile('Z:\\pyRevit\\pyKPLN_MEP\\KPLN.extension\\pyKPLN_MEP.tab\\Отверстия.panel\\Refresh.png')
		self.button14.TextImageRelation = TextImageRelation.ImageBeforeText
		self.button14.MouseEnter += self.GIFEnter
		self.button14.MouseLeave += self.PNGLeave

		self.button4.Location = Point(6, 19)
		self.button4.Size = Size(263, 33)
		self.button4.Text = "Утвердить задание"
		self.button4.Parent = self.gb2
		self.button4.Click += self.Result_Succeed

		self.button5.Location = Point(6, 93)
		self.button5.Size = Size(263, 33)
		self.button5.Text = "Оклонить (удалить все)"
		self.button5.Parent = self.gb2
		self.button5.Click += self.Result_Failed_Removed

		self.button6.Location = Point(6, 56)
		self.button6.Size = Size(263, 33)
		self.button6.Text = "Под вопросом (сохранить)"
		self.button6.Parent = self.gb2
		self.button6.Click += self.Result_Failed

		self.button7.Location = Point(12, 352)
		self.button7.Size = Size(75, 23)
		self.button7.Text = "Пропустить"
		self.button7.Parent = self
		self.button7.Click += self.SkipStep

		self.button8.Location = Point(93, 352)
		self.button8.Size = Size(75, 23)
		self.button8.Text = "Завершить"
		self.button8.Parent = self
		self.button8.Click += self.Stop

		self.button9.Location = Point(200, 34)
		self.button9.Size = Size(75, 23)
		self.button9.Text = "Обновить"
		self.button9.Parent = self
		self.button9.Click += self.Refresh
		self.button9.FlatStyle = FlatStyle.Popup

		self.label1.AutoSize = True
		self.label1.Location = Point(294, 9)
		self.label1.Name = "label1"
		self.label1.Size = Size(111, 13)
		self.label1.Text = "Комментарий"
		self.label1.Parent = self

		self.richTextBox1.Location = Point(297, 28)
		self.richTextBox1.Name = "richTextBox1"
		self.richTextBox1.Size = Size(275, 180)
		self.richTextBox1.Text = ""
		self.richTextBox1.Parent = self
		self.richTextBox1.BorderStyle = BorderStyle.Fixed3D

		self.pb.Location = Point(12, 28)
		self.pb.Name = "pictureBox1"
		self.pb.Size = Size(269, 180)
		self.pb.Parent = self
		self.pb.BorderStyle = BorderStyle.Fixed3D
		self.CenterToScreen()
		#GET WALLS
		min_x = 999
		min_y = 999
		min_z = 999
		max_x = -999
		max_y = -999
		max_z = -999
		doc_collector = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_RvtLinks).WhereElementIsNotElementType().ToElements()
		if doc_collector.Count > 0:
			for link in doc_collector:
				document = link.GetLinkDocument()
				title = ""
				try:
					title = document.Title
				except: pass
				if linked_document.Title == title:
					transform = link.GetTransform()
					wall_collector = DB.FilteredElementCollector(document).OfCategory(DB.BuiltInCategory.OST_Walls).WhereElementIsNotElementType().ToElements()
					if wall_collector.Count > 0:
						for ref in wall_collector:
							if ref.Width * 304.8 >= 80:
								geometry_object = ref.GetGeometryObjectFromReference(DB.Reference(ref))
								geometry_object_transformed = geometry_object.GetTransformed(transform)
								for item in geometry_object_transformed:
									if item.GetType() == DB.Solid:
										try:
											pt = item.ComputeCentroid()
											wall_bbox = item.GetBoundingBox()
											normalized_box = DB.BoundingBoxXYZ()
											normalized_box.Min = DB.XYZ(wall_bbox.Min.X + pt.X, wall_bbox.Min.Y + pt.Y, wall_bbox.Min.Z + pt.Z)
											normalized_box.Max = DB.XYZ(wall_bbox.Max.X + pt.X, wall_bbox.Max.Y + pt.Y, wall_bbox.Max.Z + pt.Z)
											curve = ref.Location.Curve
											self.walls.append(WallSet(ref, item, pt, normalized_box, curve.CreateTransformed(transform)))
											if min_x > normalized_box.Min.X:
												min_x = normalized_box.Min.X
											if min_y > normalized_box.Min.Y:
												min_y = normalized_box.Min.Y
											if min_z > normalized_box.Min.Z:
												min_z = normalized_box.Min.Z
											if max_x < normalized_box.Max.X:
												max_x = normalized_box.Max.X
											if max_y < normalized_box.Max.Y:
												max_y = normalized_box.Max.Y
											if max_z < normalized_box.Max.Z:
												max_z = normalized_box.Max.Z
										except: pass
		if len(self.walls) > 0:
			minx = min(int(math.copysign(math.ceil(math.fabs(min_x) / 40 ), min_x)), int(math.copysign(math.floor(math.fabs(min_x) / 40), min_x)))
			miny = min(int(math.copysign(math.ceil(math.fabs(min_y) / 40), min_y)), int(math.copysign(math.floor(math.fabs(min_y) / 40), min_y)))
			minz = min(int(math.copysign(math.ceil(math.fabs(min_z) / 40), min_z)), int(math.copysign(math.floor(math.fabs(min_z) / 40), min_z)))
			maxx = max(int(math.ceil(math.fabs(max_x) / 40) + math.fabs(minx)), int(math.floor(math.fabs(max_x) / 40) + math.fabs(minx)))
			maxy = max(int(math.ceil(math.fabs(max_y) / 40) + math.fabs(miny)), int(math.floor(math.fabs(max_y) / 40) + math.fabs(miny)))
			maxz = max(int(math.ceil(math.fabs(max_z) / 40) + math.fabs(minz)), int(math.floor(math.fabs(max_z) / 40) + math.fabs(minz)))
			self.globalBox = DB.BoundingBoxXYZ()
			self.globalBox.Min = DB.XYZ(minx, miny, minz)
			self.globalBox.Max = DB.XYZ(maxx, maxy, maxz)
			self.matrix = Matrix(self.globalBox)
			#GET TASKS
			categories = [DB.BuiltInCategory.OST_DuctCurves, DB.BuiltInCategory.OST_PipeCurves, DB.BuiltInCategory.OST_Conduit, DB.BuiltInCategory.OST_CableTray, DB.BuiltInCategory.OST_FlexDuctCurves]
			self.sys_elements = []	
			for ost_category in categories:
				element_collector = DB.FilteredElementCollector(doc).OfCategory(ost_category).WhereElementIsNotElementType().ToElements()
				if element_collector.Count > 0:
					for element in element_collector:
						try:
							if g_workset != "<все рабочие наборы>":
								if g_workset.Id.ToString() == element.WorksetId.ToString():
									options = DB.Options()
									options.ComputeReferences = False
									options.IncludeNonVisibleObjects = False
									element_geometry = element.get_Geometry(options)
									for item in element_geometry:
										if item.GetType() == DB.Solid:
											bbox = item.GetBoundingBox()
											pt = item.ComputeCentroid()
											bbox_normalized = DB.BoundingBoxXYZ()
											bbox_normalized.Min = DB.XYZ(bbox.Min.X + pt.X, bbox.Min.Y + pt.Y, bbox.Min.Z + pt.Z)
											bbox_normalized.Max = DB.XYZ(bbox.Max.X + pt.X, bbox.Max.Y + pt.Y, bbox.Max.Z + pt.Z)
											task = TaskElement(element, bbox_normalized, pt, item)
											self.tasks.append(task)
							else:
								options = DB.Options()
								options.ComputeReferences = False
								options.IncludeNonVisibleObjects = False
								element_geometry = element.get_Geometry(options)
								for item in element_geometry:
									if item.GetType() == DB.Solid:
										bbox = item.GetBoundingBox()
										pt = item.ComputeCentroid()
										bbox_normalized = DB.BoundingBoxXYZ()
										bbox_normalized.Min = DB.XYZ(bbox.Min.X + pt.X, bbox.Min.Y + pt.Y, bbox.Min.Z + pt.Z)
										bbox_normalized.Max = DB.XYZ(bbox.Max.X + pt.X, bbox.Max.Y + pt.Y, bbox.Max.Z + pt.Z)
										task = TaskElement(element, bbox_normalized, pt, item)
										self.tasks.append(task)
						except: pass
			if len(self.tasks) > 0:
				for task in self.tasks:
					self.matrix.Insert(task)
				self.matrix.Flatten()
		self.Load += self.OnLoad

	def GIFEnter(self, sender, args):
		if sender == self.button1:
			self.button1.Image = Image.FromFile('Z:\\pyRevit\\pyKPLN_MEP\\KPLN.extension\\pyKPLN_MEP.tab\\Отверстия.panel\\Group.gif')
		elif sender == self.button2:
			self.button2.Image = Image.FromFile('Z:\\pyRevit\\pyKPLN_MEP\\KPLN.extension\\pyKPLN_MEP.tab\\Отверстия.panel\\Ungroup.gif')
		elif sender == self.button3:
			self.button3.Image = Image.FromFile('Z:\\pyRevit\\pyKPLN_MEP\\KPLN.extension\\pyKPLN_MEP.tab\\Отверстия.panel\\Remove.gif')
		elif sender == self.button10:
			self.button10.Image = Image.FromFile('Z:\\pyRevit\\pyKPLN_MEP\\KPLN.extension\\pyKPLN_MEP.tab\\Отверстия.panel\\Offset.gif')
		elif sender == self.button11:
			self.button11.Image = Image.FromFile('Z:\\pyRevit\\pyKPLN_MEP\\KPLN.extension\\pyKPLN_MEP.tab\\Отверстия.panel\\OffsetAll.gif')
		elif sender == self.button12:
			self.button12.Image = Image.FromFile('Z:\\pyRevit\\pyKPLN_MEP\\KPLN.extension\\pyKPLN_MEP.tab\\Отверстия.panel\\RoundRectangle.gif')
		elif sender == self.button13:
			self.button13.Image = Image.FromFile('Z:\\pyRevit\\pyKPLN_MEP\\KPLN.extension\\pyKPLN_MEP.tab\\Отверстия.panel\\Ruler.gif')
		elif sender == self.button14:
			self.button14.Image = Image.FromFile('Z:\\pyRevit\\pyKPLN_MEP\\KPLN.extension\\pyKPLN_MEP.tab\\Отверстия.panel\\Refresh.gif')

	def PNGLeave(self, sender, args):
		if sender == self.button1:
			self.button1.Image = Image.FromFile('Z:\\pyRevit\\pyKPLN_MEP\\KPLN.extension\\pyKPLN_MEP.tab\\Отверстия.panel\\Group.png')
		elif sender == self.button2:
			self.button2.Image = Image.FromFile('Z:\\pyRevit\\pyKPLN_MEP\\KPLN.extension\\pyKPLN_MEP.tab\\Отверстия.panel\\Ungroup.png')
		elif sender == self.button3:
			self.button3.Image = Image.FromFile('Z:\\pyRevit\\pyKPLN_MEP\\KPLN.extension\\pyKPLN_MEP.tab\\Отверстия.panel\\Remove.png')
		elif sender == self.button10:
			self.button10.Image = Image.FromFile('Z:\\pyRevit\\pyKPLN_MEP\\KPLN.extension\\pyKPLN_MEP.tab\\Отверстия.panel\\Offset.png')
		elif sender == self.button11:
			self.button11.Image = Image.FromFile('Z:\\pyRevit\\pyKPLN_MEP\\KPLN.extension\\pyKPLN_MEP.tab\\Отверстия.panel\\OffsetAll.png')
		elif sender == self.button12:
			self.button12.Image = Image.FromFile('Z:\\pyRevit\\pyKPLN_MEP\\KPLN.extension\\pyKPLN_MEP.tab\\Отверстия.panel\\RoundRectangle.png')
		elif sender == self.button13:
			self.button13.Image = Image.FromFile('Z:\\pyRevit\\pyKPLN_MEP\\KPLN.extension\\pyKPLN_MEP.tab\\Отверстия.panel\\Ruler.png')
		elif sender == self.button14:
			self.button14.Image = Image.FromFile('Z:\\pyRevit\\pyKPLN_MEP\\KPLN.extension\\pyKPLN_MEP.tab\\Отверстия.panel\\Refresh.png')

	def ShowLength(self, elements):
		points = []
		offsets = []
		for element in elements:
			points.append(element.Location.Point)
			offsets.append(element.get_Parameter(DB.BuiltInParameter.INSTANCE_ELEVATION_PARAM).AsDouble())
		x_1 = points[0].X
		x_2 = points[1].X
		y_1 = points[0].Y
		y_2 = points[1].Y
		z_1 = points[0].Z + offsets[0]
		z_2 = points[1].Z + offsets[1]
		l_h = self.GetLength(DB.XYZ(x_1, y_1, 0), DB.XYZ(x_2, y_2, 0))
		l_v = self.GetLength(DB.XYZ(0, 0, z_1), DB.XYZ(0, 0, z_2))
		l_d = self.GetLength(DB.XYZ(x_1, y_1, z_1), DB.XYZ(x_2, y_2, z_2))
		H = str(round(l_h * 304.8, 2)) + "мм"
		V = str(round(l_v * 304.8, 2)) + "мм"
		D = str(round(l_d * 304.8, 2)) + "мм"
		information = "Высота x Ширина : {}x{} - {}x{}".format(str(int((elements[0].LookupParameter("Высота").AsDouble() + elements[0].LookupParameter("Расширение границ").AsDouble()*2) * 304.8)), str(int((elements[0].LookupParameter("Ширина").AsDouble() + elements[0].LookupParameter("Расширение границ").AsDouble()*2) * 304.8)), str(int((elements[1].LookupParameter("Высота").AsDouble() + elements[1].LookupParameter("Расширение границ").AsDouble()*2) * 304.8)), str(int((elements[1].LookupParameter("Ширина").AsDouble() + elements[1].LookupParameter("Расширение границ").AsDouble()*2) * 304.8)))
		length_v = "Расстояние по вертикали: {}".format(V)
		length_h = "Расстояние по горизонтали: {}".format(H)
		length_d = "Расстояние: {}".format(D)
		td = TaskDialog("")
		td.MainContent = "\n   {}\n\n   {}\n\n   {}".format(length_v, length_h, length_d)
		td.Title = "KPLN: Померить расстояние"
		td.MainInstruction = information
		td.FooterText = "Расстояние высчитывается от центра до центра элементов"
		td.Show()

	def GetLength(self, pt_1, pt_2):
		d_x = pt_1.X - pt_2.X
		d_y = pt_1.Y - pt_2.Y
		d_z = pt_1.Z - pt_2.Z
		return math.sqrt(d_x*d_x + d_y*d_y + d_z*d_z)

	def OnLoad(self, e):
		self.Disable()
		self.button7.Text = "Начать!"
		self.button7.Enabled = True

	def SetHeightDescription(self, elements):
		for i in DB.FilteredElementCollector(doc).OfClass(DB.ViewFamilyType).WhereElementIsElementType():
			if i.ViewFamily == DB.ViewFamily.ThreeDimensional:
				viewFamilyType = i
				with db.Transaction(name='Set global height'):
					zview = DB.View3D.CreateIsometric(doc, viewFamilyType.Id)
					base_point_collector = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_ProjectBasePoint).ToElements()
					for b_point in base_point_collector:
						default_offset_bp = b_point.get_BoundingBox(zview).Max.Z
						for element in elements:
							try:
								down = element.LookupParameter("SYS_OFFSET_DOWN").AsDouble()
								b_box = element.get_BoundingBox(zview)
								boundingBox_Z_min = b_box.Min.Z + down - default_offset_bp
								result_value = "Низ на отм. " + self.get_description(boundingBox_Z_min) + " мм"
								element.get_Parameter(DB.BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS).Set(result_value)
							except: pass
						break
				break
		try:
			with db.Transaction(name='Remove temporary ThreeD view'):
				doc.Delete(zview.Id)
		except: pass

	def get_description(self, length_feet):
		comma = "."
		if length_feet >= 0:
			sign = "+"
		else:
			sign = "-"
		length_feet_abs = math.fabs(length_feet)
		length_meters = int(round(length_feet_abs * 304.8 / 5, 0) * 5)
		length_string = str(length_meters)
		if len(length_string) == 7:
			value = length_string[:4] + comma + length_string[4:]
		elif len(length_string) == 6:
			value = length_string[:3] + comma + length_string[3:]
		elif len(length_string) == 5:
			value = length_string[:2] + comma + length_string[2:]
		elif len(length_string) == 4:
			value = length_string[:1] + comma + length_string[1:]
		elif len(length_string) == 3:
			value = "0{}".format(comma) + length_string
		elif len(length_string) == 2:
			value = "0{}0".format(comma) + length_string
		elif len(length_string) == 1:
			value = "0{}00".format(comma) + length_string
		value = sign + value
		return value

	def Disable(self):
		self.richTextBox1.Enabled = False
		self.button1.Enabled = False
		self.button2.Enabled = False
		self.button3.Enabled = False
		self.button4.Enabled = False
		self.button5.Enabled = False
		self.button6.Enabled = False
		self.button7.Enabled = False
		self.button8.Enabled = False
		self.button9.Enabled = False
		self.button10.Enabled = False
		self.button11.Enabled = False
		self.button12.Enabled = False
		self.button13.Enabled = False
		self.button14.Enabled = False

	def Enable(self):
		self.richTextBox1.Enabled = True
		self.button1.Enabled = True
		self.button2.Enabled = True
		self.button3.Enabled = True
		self.button4.Enabled = True
		self.button5.Enabled = True
		self.button6.Enabled = True
		self.button7.Enabled = True
		self.button8.Enabled = True
		self.button9.Enabled = True
		self.button10.Enabled = True
		self.button11.Enabled = True
		self.button12.Enabled = True
		self.button13.Enabled = True
		self.button14.Enabled = True

	def IdInList(self, element, list):
		for i in list:
			if i.Id.ToString() == element.Id.ToString():
				return True
		return False

	def StackInList(self, element, list):
		try:
			if len(list) == 0:
				return False
			for i in list:
				try:
					if str(i.Id) == str(element.Id):
						return True
				except: pass
			return False
		except: return True

	def Refresh(self, sender, args):
		self.UpdateView(doc.ActiveView)

	def GetIntersection(self, wall_solid, element_solid):
		try:
			intersection_result = DB.BooleanOperationsUtils.ExecuteBooleanOperation(wall_solid, element_solid, DB.BooleanOperationsType.Intersect)
			if abs(intersection_result.Volume) > 0.0001:	
				return intersection_result
			return False
		except: return False

	def FilterData(self, elements, data):
		uniq_ids = []
		uniq_rows = []
		for element in elements:
			try:
				for row in data:
					if str(element.Id.IntegerValue) != row.Split("@")[0]:
						if not row.Split("@")[0] in uniq_ids:
							uniq_ids.append(row.Split("@")[0])
							uniq_rows.append(row)
			except: pass
		return uniq_rows

	def Apply(self, elements, description, comments):
		try:
			with db.Transaction(name = "Set meta"):
				try:
					data_rows = doc.ProjectInformation.get_Parameter(Guid("374f4f6f-ff4c-412e-9c30-07796373f0bc")).AsString().Split("\n")
				except:
					data_rows = []
				filtered_data_rows = self.FilterData(elements, data_rows)
				for element in elements:
					try:
						filtered_data_rows.append("@".join([str(element.Id.IntegerValue),
								str(element.Location.Point.X),
								str(element.Location.Point.Y),
								str(element.Location.Point.Z),
								str(element.LookupParameter("КП_Р_Высота").AsDouble()),
								str(element.LookupParameter("КП_Р_Ширина").AsDouble()),
								str(element.get_Parameter(DB.BuiltInParameter.INSTANCE_ELEVATION_PARAM).AsDouble()),
								str(element.LevelId.IntegerValue),
								str(element.get_Parameter(Guid("ae55daa4-8182-4510-a017-32518bdfd3ce")).AsString()),
								description,
								comments]))
					except: pass
				doc.ProjectInformation.get_Parameter(Guid("374f4f6f-ff4c-412e-9c30-07796373f0bc")).Set("\n".join(filtered_data_rows))
		except Exception as e: print("def Apply : {}".format(str(e)))

	def JoinElements(self, sender, args):
		self.Hide()
		try:
			join_elements = []
			filter_openings = OpeningsSelectorFilterRectangle()
			filter_openings.SetList(self.created_elements)
			elements = uidoc.Selection.PickObjects(UI.Selection.ObjectType.Element, filter_openings, "KPLN : Веберите отверстия для объединения")
			if len(elements) == 1:
				forms.alert("Для объединения необходимо выбрать несколько элементов!")
			else:
				for item in elements:
					try:
						join_elements.append(doc.GetElement(item))
					except: pass
			if len(join_elements) != 0:
				self.PlaceOpenCombined(self.active_wall, join_elements)
		except: pass
		self.Show()

	def CheckDistance(self, sender, args):
		self.Hide()
		try:
			if len(self.created_elements) != 0:
				openings = []
				filter_openings = OpeningsSelectorFilter()
				filter_openings.SetList(self.created_elements)
				elements = uidoc.Selection.PickObjects(UI.Selection.ObjectType.Element, filter_openings, "KPLN : Веберите отверстия для поределения расстояния")
				if len(elements) != 2:
					if len(elements) == 1:
						for item in elements:
							try:	
								openings.append(doc.GetElement(item))
							except: pass
						try:
							td = TaskDialog("")
							td.MainContent = "   Высота - {}мм\n\n   Ширина - {}мм".format(str(int((openings[0].LookupParameter("Высота").AsDouble() + openings[0].LookupParameter("Расширение границ").AsDouble()*2) * 304.8)), str(int((openings[0].LookupParameter("Ширина").AsDouble() + openings[0].LookupParameter("Расширение границ").AsDouble()*2) * 304.8)))
							td.Title = "KPLN: Посмотреть значения"
							td.MainInstruction = "Параметры элемента:"
							td.Show()
						except Exception as e: print(str(e))
					else:
						forms.alert("Для просмотра расстояния необходимо выбрать два элемента!")
				else:
					for item in elements:
						try:	
							openings.append(doc.GetElement(item))
						except: pass
					try:
						self.ShowLength(openings)
					except Exception as e: print(str(e))
		except: pass
		self.Show()

	def ChangeType(self, sender, args):
		global family_symbol
		global family_symbol_round
		self.Hide()
		try:
			if len(self.created_elements) != 0:
				unjoin_elements = []
				filter_openings = OpeningsSelectorFilter()
				filter_openings.SetList(self.created_elements)
				element = doc.GetElement(uidoc.Selection.PickObject(UI.Selection.ObjectType.Element, filter_openings, "KPLN : Веберите отверстие для разделения"))
				for asset in self.assets:
					try:
						if asset.ContainsId(element.Id):
							if not asset.IsGroup():
								if asset.Element.Symbol.FamilyName == "501_Задание на отверстие в стене прямоугольное":
									with db.Transaction(name = "ChangeTypeId"):
										level = doc.GetElement(asset.Element.LevelId)
										point = asset.Element.Location.Point
										new_instance = doc.Create.NewFamilyInstance(point, family_symbol_round, level, DB.Structure.StructuralType.NonStructural)
										line = DB.Line.CreateBound(point, DB.XYZ(point.X, point.Y, point.Z + 1))
										angle = self.GetRotationAnge(asset.Wallset.Wall.Location.Curve.Direction, new_instance.FacingOrientation, asset.Wallset.Wall)
										DB.ElementTransformUtils.RotateElement(doc, new_instance.Id, line, -angle)
										width = max(asset.Element.LookupParameter("Ширина").AsDouble(), asset.Element.LookupParameter("Высота").AsDouble())
										new_instance.LookupParameter("Ширина").Set(width)
										new_instance.LookupParameter("Толщина").Set(asset.Wallset.Wall.Width)
										new_instance.LookupParameter("Расширение границ").Set(asset.Element.LookupParameter("Расширение границ").AsDouble())
										new_instance.get_Parameter(DB.BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS).Set(str(asset.Element.get_Parameter(DB.BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS).AsString()))
										new_instance.get_Parameter(DB.BuiltInParameter.INSTANCE_ELEVATION_PARAM).Set(asset.Element.get_Parameter(DB.BuiltInParameter.INSTANCE_ELEVATION_PARAM).AsDouble())
										doc.Delete(asset.Element.Id)
										asset.SetElement(new_instance)
										self.created_elements.append(new_instance)
										self.created_elements_post.append(new_instance)
										self.SetGraphics(new_instance)
								else:
									try:
										offset = asset.Element.LookupParameter("Расширение границ").AsDouble()
										with db.Transaction(name = "ChangeTypeId"):
											doc.Delete(asset.Element.Id)
										new_instance = self.PlaceOpenSingle(asset.Wallset, asset.Task[0])
										with db.Transaction(name = "ChangeValue"):
											new_instance.LookupParameter("Расширение границ").Set(offset)
									except Exception as e:
										print(str(e))
							else:
								forms.alert("Нельзя выбирать сгруппированные элементы")
					except: 
						pass
		except: 
			pass
		self.Show()

	def UnjoinElements(self, sender, args):
		self.Hide()
		try:
			if len(self.created_elements) != 0:
				unjoin_elements = []
				filter_openings = OpeningsSelectorFilterRectangle()
				filter_openings.SetList(self.created_elements)
				element = doc.GetElement(uidoc.Selection.PickObject(UI.Selection.ObjectType.Element, filter_openings, "KPLN : Веберите отверстие для разделения"))
				for asset in self.assets:
					try:
						if asset.ContainsId(element.Id):
							if asset.IsGroup():
								self.PlaceUnjoined(asset)
							else:
								forms.alert("Элемент не возможно разделить!")
					except: 
						pass
		except: 
			pass
		self.Show()

	def RemoveElements(self, sender, args):
		self.Hide()
		try:
			if len(self.created_elements) != 0:
				filter_openings = OpeningsSelectorFilter()
				filter_openings.SetList(self.created_elements)
				elements = uidoc.Selection.PickObjects(UI.Selection.ObjectType.Element, filter_openings, "KPLN : Веберите отверстия для удаления")
				for asset in self.assets:
					try:
						for reference in elements:
							element = doc.GetElement(reference)
							if asset.ContainsId(element.Id):
								asset.Remove()
					except: pass
		except: pass
		self.Show()

	def SetOffsets(self, sender, args):
		self.Hide()
		try:
			if len(self.created_elements) != 0:
				filter_openings = OpeningsSelectorFilter()
				filter_openings.SetList(self.created_elements)
				item = uidoc.Selection.PickObject(UI.Selection.ObjectType.Element, filter_openings, "KPLN : Веберите отверстия для определения смещения границ")
				value = dialog_offset.show()
				with db.Transaction(name = "SetOffset"):
					element = doc.GetElement(item)
					element.LookupParameter("Расширение границ").Set(value / 304.8)
		except: pass
		self.Show()

	def SetOffsetsToAll(self, sender, args):
		self.Hide()
		try:
			value = dialog_offset.show()
			with db.Transaction(name = "SetOffset"):
				for element in self.created_elements:
					try:
						element.LookupParameter("Расширение границ").Set(value / 304.8)
					except: pass
		except: pass
		self.Show()

	def CloseForm(self):
		self.Close()

	def Stop(self, sender, args):
		self.Hide()
		global dialog
		result = dialog.show()
		self.Show()
		if result == "1":
			self.Apply(self.created_elements, "Задание утверждено", self.richTextBox1.Text)
			self.report_succeeded.append(["Задание утверждено", self.created_elements, self.active_image, self.active_wall, self.GetLevel(self.active_wall), self.richTextBox1.Text])
		elif result == "2":
			with db.Transaction(name = "RemoveElements"):
				for item in self.created_elements:
					try:
						doc.Delete(item.Id)
					except: pass
		else:
			self.Apply(self.created_elements, "Под вопросом", self.richTextBox1.Text)
			self.report_failures.append(["Под вопросом", self.created_elements, self.active_image, self.active_wall, self.GetLevel(self.active_wall), self.richTextBox1.Text])
		r_results = []
		r_ids = []
		r_images = []
		r_walls = []
		r_levels = []
		r_comments = []
		for i in self.report_failures:
			try:
				r_ids.append(i[1])
				r_results.append(i[0])
				r_images.append(i[2])
				r_walls.append(i[3])
				r_levels.append(i[4])
				r_comments.append(i[5])
			except: pass
		for i in self.report_succeeded:
			try:
				r_ids.append(i[1])
				r_results.append(i[0])
				r_images.append(i[2])
				r_walls.append(i[3])
				r_levels.append(i[4])
				r_comments.append(i[5])
			except: pass
		self.SetOffset()
		self.PrintReport(r_results, r_ids, r_images, r_walls, r_levels, r_comments)
		self.CloseForm()

	def Force_Stop(self):
		r_results = []
		r_ids = []
		r_images = []
		r_walls = []
		r_levels = []
		r_comments = []
		if len(self.report_failures) != 0:
			for i in self.report_failures:
				try:
					r_ids.append(i[1])
					r_results.append(i[0])
					r_images.append(i[2])
					r_walls.append(i[3])
					r_levels.append(i[4])
					r_comments.append(i[5])
				except: pass
		if len(self.report_succeeded) != 0:
			for i in self.report_succeeded:
				try:
					r_ids.append(i[1])
					r_results.append(i[0])
					r_images.append(i[2])
					r_walls.append(i[3])
					r_levels.append(i[4])
					r_comments.append(i[5])
				except: pass
		self.SetOffset()
		if len(self.report_failures) + len(self.report_succeeded) != 0:
			self.PrintReport(r_results, r_ids, r_images, r_walls, r_levels, r_comments)

	def Result_Succeed(self, sender, args):
		self.Disable()
		self.Apply(self.created_elements, "Задание утверждено", self.richTextBox1.Text)
		self.report_succeeded.append(["Задание утверждено", self.created_elements, self.active_image, self.active_wall, self.GetLevel(self.active_wall), self.richTextBox1.Text])
		self.NextStep()

	def Result_Failed(self, sender, args):
		self.Disable()
		self.Apply(self.created_elements, "Под вопросом", self.richTextBox1.Text)
		self.report_failures.append(["Под вопросом", self.created_elements, self.active_image, self.active_wall, self.GetLevel(self.active_wall), self.richTextBox1.Text])
		self.NextStep()

	def Result_Failed_Removed(self, sender, args):
		self.Disable()
		with db.Transaction(name = "RemoveElements"):
			for item in self.created_elements:
				try:
					doc.Delete(item.Id)
				except: pass
		self.NextStep()

	def PlaceUnjoined(self, picked_asset):
		tasks = []
		old_assets = []
		for asset in self.assets:
			try:
				if picked_asset.Element.Id.ToString() == asset.Element.Id.ToString():
					tasks = picked_asset.Task
					wallset = picked_asset.Wallset
					picked_asset.Remove()
					break
				else:
					old_assets.append(asset)
			except:
				pass
		self.assets = []
		for asset in old_assets:
			self.assets.append(asset)
		for task in tasks:
			try:
				self.PlaceOpenSingle(wallset, task)
			except: 
				pass

	def GetLevelElevation(self, wall):
		list = []
		list_v = []
		sort_list_v = []
		ref_wall_doc = wall.Document
		ref_lvl_id = wall.LevelId
		ref_lvl = ref_wall_doc.GetElement(ref_lvl_id)
		for level in DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_Levels).WhereElementIsNotElementType().ToElements():
			list.append(level)
			list_v.append(math.fabs(level.Elevation - ref_lvl.Elevation))
			sort_list_v.append(math.fabs(level.Elevation - ref_lvl.Elevation))
			if level.Elevation == ref_lvl.Elevation:
				return level.Elevation
		sort_list_v.sort()
		for i in range(0, len(list_v)):
			if list_v[i] == sort_list_v[0]:
				return list[i].Elevation + (ref_lvl.Elevation - list[i].Elevation)

	def GetLevel(self, wallset):
		list = []
		list_v = []
		sort_list_v = []
		ref_wall_doc = wallset.Wall.Document
		ref_lvl_id = wallset.Wall.LevelId
		ref_lvl = ref_wall_doc.GetElement(ref_lvl_id)
		for level in DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_Levels).WhereElementIsNotElementType().ToElements():
			list.append(level)
			list_v.append(math.fabs(level.Elevation - ref_lvl.Elevation))
			sort_list_v.append(math.fabs(level.Elevation - ref_lvl.Elevation))
			if level.Elevation == ref_lvl.Elevation:
				return level
		sort_list_v.sort()
		for i in range(0, len(list_v)):
			if list_v[i] == sort_list_v[0]:
				return list[i]

	def BboxIntersect(self, Box_1, Box_2):
		try:
			if Box_2.Max.Z < Box_1.Min.Z or Box_2.Min.Z > Box_1.Max.Z:
				return False
			if Box_2.Max.Y < Box_1.Min.Y or Box_2.Min.Y > Box_1.Max.Y:
				return False
			if Box_2.Max.X < Box_1.Min.X or Box_2.Min.X > Box_1.Max.X:
				return False
			return True
		except: return False

	def HasOpenings(self, task):
		bbox = task.Intersection.GetBoundingBox()
		centroid = task.Intersection.ComputeCentroid()
		bbox_1 = DB.BoundingBoxXYZ()
		bbox_1.Min = DB.XYZ(bbox.Min.X + centroid.X, bbox.Min.Y + centroid.Y, bbox.Min.Z + centroid.Z)
		bbox_1.Max = DB.XYZ(bbox.Max.X + centroid.X, bbox.Max.Y + centroid.Y, bbox.Max.Z + centroid.Z)
		options = DB.Options()
		options.ComputeReferences = True
		options.IncludeNonVisibleObjects = True
		for element in DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_MechanicalEquipment).WhereElementIsNotElementType().ToElements():
			try:
				if element.Symbol.FamilyName == "501_Задание на отверстие в стене прямоугольное" or element.Symbol.FamilyName == "501_Задание на отверстие в стене круглое":
					for item in element.get_Geometry(options):
						bbox_2 = item.GetInstanceGeometry().GetBoundingBox()
						if self.BboxIntersect(bbox_1, bbox_2):
							return True
			except:
				pass
		return False

	def CalculateProperties(self, geometry, wall):
		#GET SOLID POINTS
		points = []
		if type(geometry) == DB.Solid:
			for edge in geometry.Edges:
				try:
					curve = edge.AsCurve()
					points.append(curve.GetEndPoint(0))
					points.append(curve.GetEndPoint(1))
				except: pass
		else:
			for s in geometry:
				try:
					for edge in s.Edges:
						try:
							curve = edge.AsCurve()
							points.append(curve.GetEndPoint(0))
							points.append(curve.GetEndPoint(1))
						except: pass
				except: pass
		#GET WALL CURVE
		docu = wall.Document
		docu_title = docu.Title
		for link in DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_RvtLinks).WhereElementIsNotElementType().ToElements():
			document = link.GetLinkDocument()
			title = ""
			try:
				title = document.Title
			except: pass
			if docu_title == title:
				transform = link.GetTransform()
				link_curve = wall.Location.Curve
				curve = link_curve.CreateTransformed(transform)
		#PROJECT POINTS
		projected_points = []
		length = []
		length_sorted = []
		lines = []
		lines_sorted = []
		for point in points:
			projected_points.append(curve.Project(point).XYZPoint)
		for pt_1 in projected_points:
			for pt_2 in projected_points:
				if str(pt_1) != (str(pt_2)):
					try:
						line = DB.Line.CreateBound(pt_1, pt_2)
						length.append(line.Length)
						length_sorted.append(line.Length)
						lines.append(line)
						lines_sorted.append(line)
					except: pass
		length_sorted.sort()
		for i in range(0, len(length_sorted)):
			for z in range(0, len(length)):
				if length_sorted[i] == length[z]:
					lines_sorted.append(lines[z])
		largest_line = lines_sorted[-1]
		cp = DB.XYZ((largest_line.GetEndPoint(0).X + largest_line.GetEndPoint(1).X)/2, (largest_line.GetEndPoint(0).Y + largest_line.GetEndPoint(1).Y)/2, (largest_line.GetEndPoint(0).Z + largest_line.GetEndPoint(1).Z)/2)
		if len(length_sorted) == 1:
			return [length_sorted[0], cp]
		if len(length_sorted) > 1:
			return [length_sorted[-1], cp]
		else:
			return False

	def GetCreationValues(self, task, wallset):
		intersection_box = task.Intersection.GetBoundingBox()
		max_z = intersection_box.Max.Z + task.Centroid.Z
		min_z = intersection_box.Min.Z + task.Centroid.Z
		height = round(math.fabs(max_z - min_z) / 100 * 304.8, 1) * 100 / 304.8
		calculations_result = self.CalculateProperties(task.Intersection, wallset.Wall)
		if calculations_result != False:
			width = round(calculations_result[0] / 100 * 304.8, 1) * 100 / 304.8
			center_point = calculations_result[1]
			project_level_elevation = self.GetLevelElevation(wallset.Wall)
			elevation = round((center_point.Z - project_level_elevation - height/2) / 500 * 304.8, 1) * 500 / 304.8
			return [center_point, height, width, elevation]
		else:
			return False

	def DefineOffset(self, direction_1, direction_2, wall):
		angle = math.degrees(direction_1.AngleTo(direction_2))
		if angle > 90:
			angle = 180 - angle
		cos_to = math.fabs(round(math.cos(direction_1.AngleTo(direction_2)), 2))
		try:
			add = round(wall.Width * cos_to / 500 * 304.8, 1) * 500 / 304.8
		except: add = 0.0
		return add

	def CreateInstance(self, point, symbol, wallset, task, height, width, elevation):
		try:
			level = self.GetLevel(wallset)
			d_elevation = wallset.Wall.Document.GetElement(wallset.Wall.LevelId).Elevation - level.Elevation
			with db.Transaction(name = "Create instance"):
				instance = doc.Create.NewFamilyInstance(point, symbol, level, DB.Structure.StructuralType.NonStructural)
				self.SetGraphics(instance)
				try:
					instance.get_Parameter(DB.BuiltInParameter.INSTANCE_ELEVATION_PARAM).Set(elevation + d_elevation)
				except:
					pass
				instance.LookupParameter("Высота").Set(height)
				instance.LookupParameter("Ширина").Set(width)
				instance.LookupParameter("Толщина").Set(wallset.Wall.Width)
				doc.Regenerate()
				instance.get_Parameter(Guid("ae55daa4-8182-4510-a017-32518bdfd3ce")).Set(self.GetMeta())
			created_asset = Asset(task, wallset, instance)
			self.assets.append(created_asset)
			self.created_elements.append(instance)
			self.created_elements_post.append(instance)
			return instance
		except:
			return False

	def GetMeta(self):
		log_username = System.Security.Principal.WindowsIdentity.GetCurrent().Name.split('\\')
		system_username = log_username[len(log_username) - 1]
		now = datetime.datetime.now()
		return "#".join([str(now.year), str(now.month), str(now.day), str(now.hour), str(now.minute), str(now.second), system_username])

	def GetRotationAnge(self, wallDirection, instanceFacingOrientation, wall):
		try:
			docu = wall.Document
			docu_title = docu.Title
			for link in DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_RvtLinks).WhereElementIsNotElementType().ToElements():
				document = link.GetLinkDocument()
				title = ""
				try:
					title = document.Title
				except:
					pass
				if title == docu_title:
					transform = link.GetTransform()
			wall_dir = wallDirection
			line = DB.Line.CreateBound(DB.XYZ(0,0,0), wall_dir)
			wall_dir_tr = line.CreateTransformed(transform).Direction
		except: pass

		wall_angle = math.degrees(math.atan2(wall_dir_tr.X, wall_dir_tr.Y))
		if wall_angle < 0: wall_angle+=360
		instance_angle = math.degrees(math.atan2(instanceFacingOrientation.X, instanceFacingOrientation.Y))
		if instance_angle < 0: instance_angle+=360
		true_angle = max(instance_angle, wall_angle) - min(instance_angle, wall_angle)
		if true_angle < 0: true_angle += 360
		if true_angle > 360: true_angle -= 360
		angle = math.radians(true_angle+90)
		return angle

	def PlaceOpenSingle(self, wallset, task):
		global family_symbol
		try:
			with db.Transaction(name = "Activate symbol"):
				family_symbol.Activate()
		except:
			pass
		try:
			if wallset.Curve.GetType() == DB.Line:
				max_z = -999999
				min_z = 999999
				if type(task) == type([]):
					intersections = []
					for t in task:
						intersections.append(t.Intersection)
						intersection_box = t.Intersection.GetBoundingBox()
						if max_z < intersection_box.Max.Z + task.Centroid.Z:
							max_z = intersection_box.Max.Z + task.Centroid.Z
						if min_z > intersection_box.Min.Z + task.Centroid.Z:
							min_z = intersection_box.Min.Z + task.Centroid.Z
					height = round(math.fabs(max_z - min_z) / 100 * 304.8, 1) * 100 / 304.8
					calculations_result = self.CalculateProperties(intersections, wallset.Wall)
				else:
					intersection_box = task.Intersection.GetBoundingBox()
					max_z = intersection_box.Max.Z + task.Centroid.Z
					min_z = intersection_box.Min.Z + task.Centroid.Z
					height = round(math.fabs(max_z - min_z) / 100 * 304.8, 1) * 100 / 304.8
					calculations_result = self.CalculateProperties(task.Intersection, wallset.Wall)
				if calculations_result != False:
					width = round(calculations_result[0] / 100 * 304.8, 1) * 100 / 304.8
					center_point = calculations_result[1]
					point = DB.XYZ(center_point.X, center_point.Y, (max_z + min_z)/2)
					project_level_elevation = self.GetLevelElevation(wallset.Wall)
					elevation = round((point.Z - project_level_elevation - height/2) / 100 * 304.8, 1) * 100 / 304.8
					created_instance = self.CreateInstance(center_point, family_symbol, wallset, task, height, width, elevation)
					#ROTATE
					if created_instance != False:
						line = DB.Line.CreateBound(center_point, DB.XYZ(center_point.X, center_point.Y, center_point.Z + 10))
						angle = self.GetRotationAnge(wallset.Wall.Location.Curve.Direction, created_instance.FacingOrientation, wallset.Wall)
						with db.Transaction(name = "Rotate symbol"):
							DB.ElementTransformUtils.RotateElement(doc, created_instance.Id, line, -angle)
							return created_instance
				else:
					return False
		except Exception as e:
			print(str(e))
			pass
		else: return False

	def AssetInList(self, asset, list):
		for a in list:
			try:
				if asset.Element.Id.ToString() == a.Element.Id.ToString():
					return True
			except:
				return True
		return False

	def PlaceOpenCombined(self, wallset, instances):
		try:
			global family_symbol
			try:
				with db.Transaction(name = "Activate symbol"):
					family_symbol.Activate()
			except:
				pass
			old_assets = []
			union_assets = []
			min_x = 9999999
			min_y = 9999999
			min_z = 9999999
			max_x = -9999999
			max_y = -9999999
			max_z = -9999999
			for asset in self.assets:
				try:
					for instance in instances:
						if asset.ContainsId(instance.Id):
							union_assets.append(asset)
				except: pass
			for asset in self.assets:
				try:
					if not self.AssetInList(asset, union_assets):
						old_assets.append(asset)
				except: pass
			self.assets = []
			for asset in old_assets:
				self.assets.append(asset)
			intersections = []
			tasks = []
			for asset in union_assets:
				task_list = asset.Task
				for t in task_list:
					tasks.append(t)
					intersections.append(t.Intersection)
					bb = t.BoundingBox
					if max_z < bb.Max.Z: max_z = bb.Max.Z
					if min_z > bb.Min.Z: min_z = bb.Min.Z
			height = round(math.fabs(max_z - min_z) / 100 * 304.8, 1) * 100 / 304.8
			calculations_result = self.CalculateProperties(intersections, wallset.Wall)
			if calculations_result != False:
				width = round(calculations_result[0] / 100 * 304.8, 1) * 100 / 304.8
				center_point = calculations_result[1]
				point = DB.XYZ(center_point.X, center_point.Y, (max_z + min_z)/2)
				elevation = round((point.Z - self.GetLevelElevation(wallset.Wall) - height/2) / 500 * 304.8, 1) * 500 / 304.8
				with db.Transaction(name = "RemoveOpenings"):
					for remove_instance in instances:
						try:
							doc.Delete(remove_instance.Id)
						except: pass
				created_instance = self.CreateInstance(point, family_symbol, wallset, tasks, height, width, elevation)
				#ROTATE
				if created_instance != False:
					line = DB.Line.CreateBound(center_point, DB.XYZ(center_point.X, center_point.Y,center_point.Z + 1))
					angle = self.GetRotationAnge(wallset.Wall.Location.Curve.Direction, created_instance.FacingOrientation, wallset.Wall)
					with db.Transaction(name = "Rotate symbol"):
						DB.ElementTransformUtils.RotateElement(doc, created_instance.Id, line, -angle)
			else:
				return False
		except Exception as e:
			print(str(e))

	def GetIntersections(self, wallset):
		list = []
		try:
			tasks = self.matrix.GetInserts(wallset.BoundingBox)
			for task in tasks:
				intersection = self.GetIntersection(wallset.Solid, task.Solid)
				if intersection != False:
					task.SetIntersection(intersection)
					if not self.HasOpenings(task):
						list.append(task)
		except:
			pass
		return list

	def UpdateView(self, view):
		log_username = System.Security.Principal.WindowsIdentity.GetCurrent().Name.Split('\\')
		system_username = log_username[len(log_username) - 1]
		now = datetime.datetime.now()
		time = "{}{}{}-{}_{}_{}".format(now.year, now.month, now.day, now.hour, now.minute, now.second)
		jpeg_folder = "{}_{}".format(system_username, "MEP{}{}{}({})_{}".format(now.year, now.month, now.day, now.hour, system_username))
		file_name = doc.Title.replace('.rvt', '')
		file_name += "({})".format(time)
		views = List[DB.ElementId]([view.Id])
		export_options = DB.ImageExportOptions()
		export_options.ZoomType = DB.ZoomFitType.FitToPage
		export_options.PixelSize = 400
		export_options.FilePath = "Z:\\pyRevit\\Applications\\Reports\\{}\\{}.jpg".format(jpeg_folder, file_name)
		directory = "Z:\\pyRevit\\Applications\\Reports\\{}".format(jpeg_folder)
		try:
			os.stat(directory)
		except:
			os.mkdir(directory)
		export_options.FitDirection = DB.FitDirectionType.Horizontal
		export_options.ImageResolution = DB.ImageResolution.DPI_600
		export_options.ExportRange = DB.ExportRange.VisibleRegionOfCurrentView
		export_options.HLRandWFViewsFileType = DB.ImageFileType.JPEGLossless;
		export_options.ShadowViewsFileType = DB.ImageFileType.JPEGLossless;
		try:
			doc.ExportImage(export_options)
			self.pb.Image = Image.FromFile("Z:\\pyRevit\\Applications\\Reports\\{}\\{}.jpg".format(jpeg_folder, file_name))
			self.active_image = "Z:\\pyRevit\\Applications\\Reports\\{}\\{}.jpg".format(jpeg_folder, file_name)
		except: pass

	def SkipStep(self, sender, args):
		with db.Transaction(name = "RemoveOpenings"):
			if len(self.created_elements) != 0:
				for item in self.created_elements:
					try:
						doc.Delete(item.Id)
					except: pass
		self.button7.Text = "Пропустить"
		self.Disable()
		self.richTextBox1.Text = ""
		self.assets = []
		self.created_elements = []
		for asset in self.assets:
			asset.Remove()
		self.Text = "KPLN Стены : {} из {}".format(self.step, len(self.walls))
		v = len(self.walls)
		with forms.ProgressBar(title='Wall {value} of {max_value}') as pb:
			while True:
				pb.update_progress(self.step, max_value = v)
				try:
					tasks = self.GetIntersections(self.walls[self.step])
					if len(tasks) > 0 and self.step <= len(self.walls)-1:
						self.active_wall = self.walls[self.step]
						self.Text = "KPLN Стены : {} из {}".format(str(self.step), str(len(self.walls)))
						for t in tasks:
							self.PlaceOpenSingle(self.active_wall, t)
						self.ActivateView(self.active_wall)
						self.step += 1
						self.Text = "KPLN Стены : {} из {}".format(str(self.step), str(len(self.walls)))
						self.Enable()
						return
					else:
						self.step += 1
						self.Text = "KPLN Стены : {} из {}".format(str(self.step), str(len(self.walls)))
						if self.step >= len(self.walls)-1:
							self.Force_Stop()
							break
						continue
				except:
					self.Force_Stop()
					break
				if self.step >= len(self.walls):
					self.Force_Stop()
					break
		self.CloseForm()
		return

	def NextStep(self):
		self.Disable()
		self.richTextBox1.Text = ""
		self.assets = []
		self.created_elements = []
		self.Text = "KPLN Стены : {} из {}".format(self.step, len(self.walls))
		v = len(self.walls)
		with forms.ProgressBar(title='Wall {value} of {max_value}') as pb:
			while True:
				pb.update_progress(self.step, max_value = v)
				try:
					tasks = self.GetIntersections(self.walls[self.step])
					if len(tasks) > 0 and self.step < len(self.walls)-1:
						self.active_wall = self.walls[self.step]
						self.Text = "KPLN Стены : {} из {}".format(str(self.step), str(len(self.walls)))
						for t in tasks:
							self.PlaceOpenSingle(self.active_wall, t)
						self.ActivateView(self.active_wall)
						self.step += 1
						self.Text = "KPLN Стены : {} из {}".format(str(self.step), str(len(self.walls)))
						self.Enable()
						return
					else:
						self.step += 1
						self.Text = "KPLN Стены : {} из {}".format(str(self.step), str(len(self.walls)))
						if self.step >= len(self.walls)-1:
							self.Force_Stop()
							break
						continue
				except:
					self.Force_Stop()
					break
				if self.step >= len(self.walls):
					self.Force_Stop()
					break
		self.CloseForm()

	def SetGraphics(self, element):
		fillPatternElement = None
		for name in ["Solid fill", "Сплошная заливка", "сплошная заливка", "solid fill"]:
			try:
				fillPatternElement = DB.FillPatternElement.GetFillPatternElementByName(doc, DB.FillPatternTarget.Drafting, name)
				if fillPatternElement != None:
					for view in DB.FilteredElementCollector(doc).OfClass(DB.View3D).WhereElementIsNotElementType():
						if view.get_Parameter(DB.BuiltInParameter.VIEW_NAME).AsString() == "SYS_OPENINGS":
							settings = DB.OverrideGraphicSettings()
							settings.SetProjectionFillPatternId(fillPatternElement.Id)
							settings.SetProjectionLineColor(DB.Color(255, 0, 255))
							settings.SetProjectionLineWeight(4)
							settings.SetSurfaceTransparency(10)
							settings.SetHalftone(False)
							view.SetElementOverrides(element.Id, settings)
							return
			except: pass

	def ActivateView(self, wallset):
		try:
			if uidoc.ActiveView.get_Parameter(DB.BuiltInParameter.VIEW_NAME).AsString() != "SYS_OPENINGS":
				collector_viewFamily = DB.FilteredElementCollector(doc).OfClass(DB.View3D).WhereElementIsNotElementType()
				bool = False
				for view in collector_viewFamily:
					if view.get_Parameter(DB.BuiltInParameter.VIEW_NAME).AsString() == "SYS_OPENINGS":
						zview = view
						bool = True
						uidoc.ActiveView = zview
				if not bool:
					collector_viewFamilyType = DB.FilteredElementCollector(doc).OfClass(DB.ViewFamilyType).WhereElementIsElementType()
					for view in collector_viewFamilyType:
						if view.ViewFamily == DB.ViewFamily.ThreeDimensional:
							viewFamilyType = view
							break
					with db.Transaction(name = "CreateView"):
						zview = DB.View3D.CreateIsometric(doc, viewFamilyType.Id)
						zview.get_Parameter(DB.BuiltInParameter.VIEW_NAME).Set("SYS_OPENINGS")
					return False
			a_view = uidoc.ActiveView
			with db.Transaction(name = "Reset"):
				a_view.CropBoxActive = False
			with db.Transaction(name = "ModifyView"):
				pt = DB.XYZ(0,0,0)
				clipbox = DB.BoundingBoxXYZ()
				clipbox.Min = DB.XYZ(wallset.BoundingBox.Min.X + pt.X - 1, wallset.BoundingBox.Min.Y + pt.Y - 1, wallset.BoundingBox.Min.Z + pt.Z - 50 / 304.8)
				clipbox.Max = DB.XYZ(wallset.BoundingBox.Max.X + pt.X + 1, wallset.BoundingBox.Max.Y + pt.Y + 1, wallset.BoundingBox.Max.Z + pt.Z - 50 / 304.8)
				a_view.SetSectionBox(clipbox)
				eye_position = DB.XYZ((wallset.BoundingBox.Min.X + wallset.BoundingBox.Max.X)/2, (wallset.BoundingBox.Min.Y + wallset.BoundingBox.Max.Y)/2, (wallset.BoundingBox.Min.Z + wallset.BoundingBox.Max.Z)/2)
				forward_direction = self.VectorFromHorizVertAngles(135, -30)
				up_direction = self.VectorFromHorizVertAngles(135, -30 + 90 )
				orientation = DB.ViewOrientation3D(eye_position, up_direction, forward_direction)
				a_view.SetOrientation(orientation)
			with db.Transaction(name = "Colorify"):
				for workset in DB.FilteredWorksetCollector(doc).OfKind(DB.WorksetKind.UserWorkset).ToWorksets():
					try:
						a_view.SetWorksetVisibility(workset.Id, DB.WorksetVisibility.Visible)
					except: pass
				a_view.DetailLevel = DB.ViewDetailLevel.Fine
				self.SetColor(a_view)
				self.ZoomBbox(wallset, a_view)
				self.UpdateView(a_view)
		except: return False
		return True

	def VectorFromHorizVertAngles(self, angleHorizD, angleVertD):
		degToRadian = math.pi * 2 / 360
		angleHorizR = angleHorizD * degToRadian
		angleVertR = angleVertD * degToRadian
		a = math.cos(angleVertR)
		b = math.cos(angleHorizR)
		c = math.sin(angleHorizR)
		d = math.sin(angleVertR)
		return DB.XYZ(a*b, a*c, d)

	def SetColor(self, view):
		collector_elements = DB.FilteredElementCollector(doc, view.Id).WhereElementIsNotElementType().ToElements()
		fillPatternElement = None
		dict = ["Solid fill", "Сплошная заливка", "сплошная заливка", "solid fill"]
		for name in dict:
			try:
				fillPatternElement = DB.FillPatternElement.GetFillPatternElementByName(doc, DB.FillPatternTarget.Drafting, name)
				if fillPatternElement != None:
					break
			except: pass
		for built_in_category in [DB.BuiltInCategory.OST_DuctCurves, DB.BuiltInCategory.OST_PipeCurves, DB.BuiltInCategory.OST_Conduit, DB.BuiltInCategory.OST_CableTray, DB.BuiltInCategory.OST_FlexDuctCurves]:
			try:
				category = DB.Category.GetCategory(doc, built_in_category)
				settings = DB.OverrideGraphicSettings()
				settings.SetProjectionLineColor(DB.Color(0, 0, 255))
				settings.SetProjectionLineWeight(4)
				settings.SetHalftone(False)
				settings.SetProjectionFillPatternId(fillPatternElement.Id)
				settings.SetSurfaceTransparency(10)
				view.SetCategoryOverrides(category.Id, settings)
			except: pass
		for cat in [DB.BuiltInCategory.OST_DuctCurves, DB.BuiltInCategory.OST_PipeCurves, DB.BuiltInCategory.OST_Conduit, DB.BuiltInCategory.OST_CableTray, DB.BuiltInCategory.OST_FlexDuctCurves]:
			for element in DB.FilteredElementCollector(doc, view.Id).OfCategory(cat).WhereElementIsNotElementType().ToElements():
				try:
					category = DB.Category.GetCategory(doc, built_in_category)
					settings = DB.OverrideGraphicSettings()
					settings.SetProjectionLineColor(DB.Color(0, 0, 255))
					settings.SetProjectionLineWeight(4)
					settings.SetHalftone(False)
					settings.SetProjectionFillPatternId(fillPatternElement.Id)
					settings.SetSurfaceTransparency(10)
					view.SetElementOverrides(element.Id, settings)
				except: pass
		try:
			for cat in [DB.BuiltInCategory.OST_Walls, DB.BuiltInCategory.OST_Floors, DB.BuiltInCategory.OST_Ceilings]:
				category = DB.Category.GetCategory(doc, cat)
				settings = DB.OverrideGraphicSettings()
				settings.SetProjectionLineColor(DB.Color(0, 0, 0))
				settings.SetProjectionLineWeight(1)
				settings.SetHalftone(False)
				settings.SetProjectionFillPatternId(fillPatternElement.Id)
				settings.SetProjectionFillColor(DB.Color(230, 230, 230))
				settings.SetSurfaceTransparency(80)
				view.SetCategoryOverrides(category.Id, settings)
		except: pass
		for element in DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_MechanicalEquipment).WhereElementIsNotElementType().ToElements():
			try:
				if element.Symbol.FamilyName == "501_Задание на отверстие в стене прямоугольное" or element.Symbol.FamilyName == "501_Задание на отверстие в стене круглое":
					if len(self.created_elements) != 0:
						if self.IdInList(element, self.created_elements):
							settings = DB.OverrideGraphicSettings()
							settings.SetProjectionFillPatternId(fillPatternElement.Id)
							settings.SetProjectionLineColor(DB.Color(255, 0, 255))
							settings.SetProjectionLineWeight(4)
							settings.SetSurfaceTransparency(10)
							settings.SetHalftone(False)
							view.SetElementOverrides(element.Id, settings)
							continue
						else:
							settings = DB.OverrideGraphicSettings()
							settings.SetProjectionLineColor(DB.Color(0, 0, 255))
							settings.SetProjectionLineWeight(1)
							settings.SetHalftone(False)
							settings.SetProjectionFillPatternId(fillPatternElement.Id)
							settings.SetSurfaceTransparency(50)
							view.SetElementOverrides(element.Id, settings)
							continue
					else:
						settings = DB.OverrideGraphicSettings()
						settings.SetProjectionLineColor(DB.Color(0, 0, 255))
						settings.SetProjectionLineWeight(1)
						settings.SetHalftone(False)
						settings.SetProjectionFillPatternId(fillPatternElement.Id)
						settings.SetSurfaceTransparency(50)
						view.SetElementOverrides(element.Id, settings)
						continue
			except:
				pass

	def ZoomBbox(self, wallset, view):
		views = uidoc.GetOpenUIViews()
		for v in views:
			if str(v.ViewId) == str(view.Id):
				v.ZoomAndCenterRectangle(wallset.BoundingBox.Min, wallset.BoundingBox.Max)

	def GetUpperElevation(self, element):
		elevation = doc.GetElement(element.LevelId).Elevation
		elevations = []
		for level in DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_Levels).WhereElementIsNotElementType().ToElements():
			if level.Elevation > elevation and level.Elevation - elevation > 1600/304.8:
				elevations.append(level.Elevation - elevation)
		elevations.sort()
		if len(elevations) != 0:
			return elevations[0]
		else:
			return 3000 / 304.8 - element.get_Parameter(DB.BuiltInParameter.INSTANCE_ELEVATION_PARAM).AsDouble() - element.LookupParameter("Высота").AsDouble()

	def GetBottonElevation(self, element):
		level_main = doc.GetElement(element.LevelId)
		if level_main.get_Parameter(DB.BuiltInParameter.LEVEL_IS_BUILDING_STORY).AsInteger() == 1:
			return element.get_Parameter(DB.BuiltInParameter.INSTANCE_ELEVATION_PARAM).AsDouble()
		else:
			elevation = level_main.Elevation
			elevations = []
			for level in DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_Levels).WhereElementIsNotElementType().ToElements():
				if level.Elevation < elevation and elevation - level.Elevation > 1600/304.8:
					elevations.append(math.fabs(elevation - level.Elevation))
			elevations.sort()
			if len(elevations) != 0:
				return elevations[0]
			else:
				element.get_Parameter(DB.BuiltInParameter.INSTANCE_ELEVATION_PARAM).AsDouble()

	def SetOffset(self):
		try:
			if len(self.created_elements_post) != 0:
				self.SetHeightDescription(self.created_elements_post)
				with db.Transaction(name = "ChangeElements"):	
					for element in self.created_elements_post:
						try:
							element.LookupParameter("SYS_OFFSET_DOWN").Set(math.fabs(self.GetBottonElevation(element)))
							element.LookupParameter("SYS_OFFSET_UP").Set(math.fabs(self.GetUpperElevation(element)))
						except: pass
		except: pass

	def PrintReport(self, results, ids, images, walls, levels, comments):
		log_username = System.Security.Principal.WindowsIdentity.GetCurrent().Name.split('\\')
		system_username = log_username[len(log_username) - 1]
		now = datetime.datetime.now()
		time = "{}/{}/{} {}:{}:{}".format(now.year, now.month, now.day, now.hour, now.minute, now.second)
		self.output.print_html('<font size="4"><b>Отчет подготовил: </b><font color=#0066ff size="4"><ruby>{}<rt>Windows</rt></ruby> (<ruby>{}<rt>Revit</rt></ruby>)</font><br><b>Дата запуска:</b> {}<hr>'.format(system_username, doc.Application.Username, time))
		self.output.print_html('<b>Локальный путь:</b> {}'.format(doc.PathName))
		if doc.IsWorkshared:
			try:
				self.output.print_html('<b>Хранилище:</b> {}'.format(DB.BasicFileInfo.Extract(doc.PathName).CentralPath))
			except: pass
		self.output.print_html('<hr><br>')
		part = ""
		for i in range(0, len(results)):
			try:
				ids1 = ""
				part += '<tr>'
				for element in ids[i]:
					try:
						ids1 += self.output.linkify(element.Id)
						ids1 += '<br>'
					except:
						ids1 += ""
				if results[i] == "Под вопросом":
					part += '<td><center><font color=#ff6666><h3>{}</h1></font></center></td>'.format(results[i])
				elif results[i] == "Задание утверждено":
					part += '<td><center><font color=#009900><h3>{}</h1></font></center></td>'.format(results[i])
				else:
					part += '<td><center><font color=#b4b4b4><h3>{}</h1></font></center></td>'.format(results[i])
				part += '<td><center>{}</center></td>'.format(ids1)
				part += '<td><center><img src="{}" alt=""></center></td>'.format(str(images[i]))
				part += '<td><center>{}</center></td>'.format(self.output.linkify(walls[i].Wall.Id))
				part += '<td><center><q>{}</q></center></td>'.format(levels[i].Name)
				part += '<td><center>{}</center></td>'.format(comments[i])
				part += '</tr>'
			except: pass
		self.output.print_html('<table align="center" cols="6"><caption></caption>'\
				  '<tr>'\
				  '<th>Результат</th>'\
				  '<th>Id отверстий (задания)</th>'\
				  '<th>Эскиз</th>'\
				  '<th>Id стены</th>'\
				  '<th>Уровень</th>'\
				  '<th>Комментарий</th>' + part + '</table>')

def LoadParameter(path, category, group, name, type, allow_vary):
	try:
		if os.path.exists(path):
			app = doc.Application
			category_set = app.Create.NewCategorySet()
			category_set.Insert(doc.Settings.Categories.get_Item(category))
			originalFile = app.SharedParametersFilename
			app.SharedParametersFilename = path
			SharedParametersFile = app.OpenSharedParameterFile()
			map = doc.ParameterBindings
			it = map.ForwardIterator()
			it.Reset()
			while it.MoveNext():
				d_Definition = it.Key
				d_Name = it.Key.Name
				d_Binding = it.Current
				d_catSet = d_Binding.Categories	
				if d_Name == name:
					if d_Binding.GetType() == DB.InstanceBinding:
						if str(d_Definition.ParameterType) == type:
							if d_Definition.VariesAcrossGroups == allow_vary:
								if d_catSet.Contains(DB.Category.GetCategory(doc, category)):
									return True
			with db.Transaction(name = "AddSharedParameter"):
				for dg in SharedParametersFile.Groups:
					if dg.Name == group:
						externalDefinition = dg.Definitions.get_Item(name)
						newIB = app.Create.NewInstanceBinding(category_set)
						doc.ParameterBindings.Insert(externalDefinition, newIB, DB.BuiltInParameterGroup.PG_DATA)
						doc.ParameterBindings.ReInsert(externalDefinition, newIB, DB.BuiltInParameterGroup.PG_DATA)
			it.Reset()
			with db.Transaction(name = "SetAllowVaryBetweenGroups"):
				while it.MoveNext():
					d_Definition = it.Key
					d_Name = it.Key.Name
					if d_Name == name:
						try:
							d_Definition.SetAllowVaryBetweenGroups(doc, allow_vary)
						except: pass
		else: return False
		return True
	except Exception as e: 
		print(str(e))
		return False

linked_document = None
g_workset = None
sys_type = ""
family_symbol = None
LoadParameter("Z:\\Отдел BIM\\02_Внутренняя документация\\05_ФОП\\ФОП2019_КП_АР.txt", DB.BuiltInCategory.OST_ProjectInformation, "SYSTEM", "SYS_COORDINATION_OPENINGS_TASKS_LIST", "MultilineText", True)
LoadParameter("Z:\\Отдел BIM\\02_Внутренняя документация\\05_ФОП\\ФОП2019_КП_АР.txt", DB.BuiltInCategory.OST_MechanicalEquipment, "SYSTEM", "SYS_COORDINATION_META", "MultilineText", True)

if uidoc.ActiveView.get_Parameter(DB.BuiltInParameter.VIEW_NAME).AsString() != "SYS_OPENINGS":
	collector_viewFamily = DB.FilteredElementCollector(doc).OfClass(DB.View3D).WhereElementIsNotElementType()
	bool = False
	for view in collector_viewFamily:
		if view.get_Parameter(DB.BuiltInParameter.VIEW_NAME).AsString() == "SYS_OPENINGS":
			zview = view
			bool = True
			uidoc.ActiveView = zview
	if not bool:
		collector_viewFamilyType = DB.FilteredElementCollector(doc).OfClass(DB.ViewFamilyType).WhereElementIsElementType()
		for view in collector_viewFamilyType:
			if view.ViewFamily == DB.ViewFamily.ThreeDimensional:
				viewFamilyType = view
				break
		with db.Transaction(name = "CreateView"):
			zview = DB.View3D.CreateIsometric(doc, viewFamilyType.Id)
			zview.get_Parameter(DB.BuiltInParameter.VIEW_NAME).Set("SYS_OPENINGS")

class LoadOptions(DB.IFamilyLoadOptions):
	def OnFamilyFound (self, familyInUse, overwriteParameterValues):
		return True
	def OnSharedFamilyFound (self, sharedFamily, familyInUse, source, overwriteParameterValues):
		return True
load_options = LoadOptions()

family = False
family_round = False

with db.Transaction(name = "Activation"):
	for symbol in DB.FilteredElementCollector(doc).OfClass(DB.FamilySymbol).OfCategory(DB.BuiltInCategory.OST_MechanicalEquipment):
		if symbol.FamilyName == "501_Задание на отверстие в стене прямоугольное":
			family = symbol.Family
			symbol.Activate()
			family_box = clr.StrongBox[DB.Family](family)
		elif symbol.FamilyName == "501_Задание на отверстие в стене круглое":
			family_round = symbol.Family
			symbol.Activate()
			family_box_round = clr.StrongBox[DB.Family](family)

form_1 = ChoseFilter()
result = "default"
Application.Run(form_1)

if result != "cancel":
	commands = [CommandLink('Утвердить', return_value="1"), CommandLink('Отменить и удалить все', return_value="2"), CommandLink('Сохранить с пометкой', return_value="3")]
	dialog = TaskDialog('Выберите действие для последнего расчета',
			title = "Группировка",
			title_prefix=False,
			content="",
			commands=commands,
			footer='',
			show_close=False)

	commands_offset = [CommandLink('0 мм', return_value=0.0), CommandLink('50 мм', return_value=50.0), CommandLink('100 мм', return_value=100.0), CommandLink('150 мм', return_value=150.0)]
	dialog_offset = TaskDialog('Выберите размер отступа для элемента',
			title = "Отступ",
			title_prefix=False,
			content="",
			commands=commands_offset,
			footer='',
			show_close=False)

	with db.Transaction(name = "Load families"):
		if family == False:
			try:
				doc.LoadFamily("Z:\\pyRevit\\Applications\\LoadUtils\\501_Задание на отверстие в стене прямоугольное.rfa")
			except: pass
		else:
			try:
				doc.LoadFamily("Z:\\pyRevit\\Applications\\LoadUtils\\501_Задание на отверстие в стене прямоугольное.rfa", load_options, family_box)
			except: pass
		if family_round == False:
			try:
				doc.LoadFamily("Z:\\pyRevit\\Applications\\LoadUtils\\501_Задание на отверстие в стене круглое.rfa")
			except: pass
		else:
			try:
				doc.LoadFamily("Z:\\pyRevit\\Applications\\LoadUtils\\501_Задание на отверстие в стене круглое.rfa", load_options, family_box_round)
			except: pass
	with db.Transaction(name = "Load families"):
		family_symbol_collector = DB.FilteredElementCollector(doc).OfClass(DB.FamilySymbol).OfCategory(DB.BuiltInCategory.OST_MechanicalEquipment)
		for symbol in family_symbol_collector:
			if symbol.FamilyName == "501_Задание на отверстие в стене прямоугольное":
				if symbol.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString() == sys_type:
					family_symbol = symbol
					symbol.Activate()
			if symbol.FamilyName == "501_Задание на отверстие в стене круглое":
				if symbol.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString() == sys_type:
					family_symbol_round = symbol
					symbol.Activate()
	if family_symbol != None and family_symbol_round != None:
		form_2 = RunParser()
		Application.Run(form_2)
	else:
		forms.alert("Внутренняя ошибка : отсутствует типоразмер «{}»\nПопробуйте подгрузить семейство вручную (Z:\\pyRevit\\Applications\\LoadUtils\\501_Задание на отверстие в стене прямоугольное.rfa, Z:\\pyRevit\\Applications\\LoadUtils\\501_Задание на отверстие в стене круглое.rfa)".format(sys_type))