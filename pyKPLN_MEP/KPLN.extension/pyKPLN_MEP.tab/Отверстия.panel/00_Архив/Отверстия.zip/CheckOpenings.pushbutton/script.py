# -*- coding: utf-8 -*-
"""
CheckOpenings

"""
__author__ = 'Igor Perfilyev - envato.perfilev@gmail.com'
__title__ = "Мониторинг\nзаданий"
__doc__ = 'Анализ неодобренных/измененных элементов' \

"""
Архитекурное бюро KPLN

"""
import math
import time
import os
import System
from pyrevit.framework import clr
import re
from rpw import doc, uidoc, DB, UI, db, ui, revit as Revit
from pyrevit import script
from pyrevit import forms
from pyrevit import revit, DB, UI
from pyrevit.revit import Transaction, selection
from System.Collections.Generic import *
import datetime
from System.Windows.Forms import *
from System.Drawing import *
from System import Guid
from rpw.ui.forms import CommandLink, TaskDialog, Alert

class Tab():
	def __init__(self, parent, position, element):
		self.Group = GroupBox()
		self.Group.Parent = parent
		self.Group.Text = "{} ({}) <{}>".format(element.Element.Symbol.FamilyName, element.Element.Name, str(element.Element.Id.IntegerValue))
		self.Group.Location = Point(12, position)
		self.Group.Size = Size(560, 200)
		self.ParentForm = parent
		self.Element = element.Element

		self.Button_Approve = Button()
		self.Button_Approve.Parent = self.Group
		self.Button_Approve.Text = "Утвердить"
		self.Button_Approve.Location = Point(10,165)
		self.Button_Approve.Size = Size(85,23)
		self.Button_Approve.Image = Image.FromFile('Z:\\pyRevit\\pyKPLN_MEP\\KPLN.extension\\pyKPLN_MEP.tab\\Отверстия.panel\\CheckOpenings.pushbutton\\IconApprove.png')
		self.Button_Approve.TextImageRelation = TextImageRelation.ImageBeforeText
		self.Button_Approve.Click += self.Approve

		self.Button_ApplyChanges = Button()
		self.Button_ApplyChanges.Parent = self.Group
		self.Button_ApplyChanges.Text = "Применить"
		self.Button_ApplyChanges.Location = Point(100,165)
		self.Button_ApplyChanges.Size = Size(90,23)
		self.Button_ApplyChanges.Image = Image.FromFile('Z:\\pyRevit\\pyKPLN_MEP\\KPLN.extension\\pyKPLN_MEP.tab\\Отверстия.panel\\CheckOpenings.pushbutton\\IconApply.png')
		self.Button_ApplyChanges.TextImageRelation = TextImageRelation.ImageBeforeText
		self.Button_ApplyChanges.Click += self.Apply

		self.Button_Remove = Button()
		self.Button_Remove.Parent = self.Group
		self.Button_Remove.Text = "Удалить"
		self.Button_Remove.Location = Point(195,165)
		self.Button_Remove.Size = Size(75,23)
		self.Button_Remove.Image = Image.FromFile('Z:\\pyRevit\\pyKPLN_MEP\\KPLN.extension\\pyKPLN_MEP.tab\\Отверстия.panel\\CheckOpenings.pushbutton\\IconRemove.png')
		self.Button_Remove.TextImageRelation = TextImageRelation.ImageBeforeText
		self.Button_Remove.Click += self.Remove

		self.Button_Zoom = Button()
		self.Button_Zoom.Parent = self.Group
		self.Button_Zoom.Text = "Посмотреть"
		self.Button_Zoom.Location = Point(275,165)
		self.Button_Zoom.Size = Size(95,23)
		self.Button_Zoom.Image = Image.FromFile('Z:\\pyRevit\\pyKPLN_MEP\\KPLN.extension\\pyKPLN_MEP.tab\\Отверстия.panel\\CheckOpenings.pushbutton\\IconZoom.png')
		self.Button_Zoom.TextImageRelation = TextImageRelation.ImageBeforeText
		self.Button_Zoom.Click += self.Zoom

		self.Label_Meta = Label()
		self.Label_Meta.Parent = self.Group
		self.Label_Meta.Text = element.MetaString
		self.Label_Meta.Location = Point(10,20)
		self.Label_Meta.Size = Size(250, 30)
		self.Changes = "Изменения:\n"
		if element.LocationChanged: self.Changes += " - Позиция изменена\n"
		if element.HeightChanged: self.Changes += " - Высота изменена\n"
		if element.WidthChanged: self.Changes += " - Ширина изменена\n"
		if element.OffsetChanged: self.Changes += " - Смещение изменено\n"
		if element.LevelChanged: self.Changes += " - Уровень изменен\n"
		self.Label_Changed = Label()
		self.Label_Changed.Parent = self.Group
		self.Label_Changed.Text = self.Changes
		self.Label_Changed.Location = Point(10,55)
		self.Label_Changed.Size = Size(250, 120)

		self.Label_Comments = Label()
		self.Label_Comments.Parent = self.Group
		self.Label_Comments.Text = "Комментарий автора:"
		self.Label_Comments.Location = Point(300,20)
		self.Label_Comments.Size = Size(200, 15)

		self.TBox = RichTextBox()
		self.TBox.Parent = self.Group
		self.TBox.Text = element.Comments
		self.TBox.Location = Point(300, 45)
		self.TBox.Size = Size(252, 112)
		self.TBox.BorderStyle = BorderStyle.FixedSingle

	def RemoveAlert(self):
		self.TD = UI.TaskDialog("KPLN Координация : Мониторинг")
		self.TD.TitleAutoPrefix = False
		self.TD.MainInstruction = "Удаление"
		self.TD.MainContent = "Мониторинг данного элемента завершен!"
		self.TD.FooterText = "Соответствующие заданиям отверстия будут помечены как неактуальные (данное действие можно отменить)"
		self.TD.Show()

	def Remove(self, sender, args):
		self.ParentForm.Hide()
		self.RemoveAlert()
		global data_rows
		self.Group.Enabled = False
		self.Group.Visible = False
		num = -1
		for i in range(0, len(self.ParentForm.Tabs)):
			if self == self.ParentForm.Tabs[i]:
				self.ParentForm.Tabs.remove(self)
				num = i
				break
		if num != -1:
			for i in range(0, len(self.ParentForm.Tabs)-num):
				if self.ParentForm.Tabs[i+num].Group.Visible:
					self.ParentForm.Tabs[i+num].Group.Location = Point(self.ParentForm.Tabs[i+num].Group.Location.X, self.ParentForm.Tabs[i+num].Group.Location.Y-210)
		id = str(self.Element.Id.IntegerValue)
		new_rows = []
		for row in data_rows:
			if id != row.Split("@")[0]:
				new_rows.append(row)
		data_rows = new_rows
		try:
			with db.Transaction(name = "RemoveItem"):
				doc.ProjectInformation.get_Parameter(Guid("374f4f6f-ff4c-412e-9c30-07796373f0bc")).Set("\n".join(data_rows))
				doc.Delete(self.Element.Id)
		except Exception as e: 
			print(str(e))
			pass
		self.ParentForm.Show()
		if len(self.ParentForm.Tabs) == 0:
			self.ParentForm.Close()

	def Apply(self, sender, args):
		id = str(self.Element.Id.IntegerValue)
		self.Group.Enabled = False
		global data_rows
		new_rows = []
		current_row = ""
		for row in data_rows:
			if id != row.Split("@")[0]:
				new_rows.append(row)
			else:
				current_row = row.Split("@")
		data_rows = new_rows
		try:
			with db.Transaction(name = "Set Meta"):
				self.Element.get_Parameter(Guid("ae55daa4-8182-4510-a017-32518bdfd3ce")).Set(self.GetMeta())
		except Exception as e: 
			print(str(e))
			pass
		data_rows.append("@".join([str(self.Element.Id.IntegerValue),
				current_row[1],
				current_row[2],
				current_row[3],
				current_row[4],
				current_row[5],
				current_row[6],
				current_row[7],
				str(self.Element.get_Parameter(Guid("ae55daa4-8182-4510-a017-32518bdfd3ce")).AsString()),
				"Под вопросом",
				str(self.TBox.Text)]))
		try:
			with db.Transaction(name = "Update Meta"):
				doc.ProjectInformation.get_Parameter(Guid("374f4f6f-ff4c-412e-9c30-07796373f0bc")).Set("\n".join(data_rows))
		except Exception as e: 
			print(str(e))
			pass

	def GetMeta(self):
		log_username = System.Security.Principal.WindowsIdentity.GetCurrent().Name.split('\\')
		system_username = log_username[len(log_username) - 1]
		now = datetime.datetime.now()
		return "#".join([str(now.year), str(now.month), str(now.day), str(now.hour), str(now.minute), str(now.second), system_username])

	def Approve(self, sender, args):
		id = str(self.Element.Id.IntegerValue)
		self.Group.Enabled = False
		global data_rows
		new_rows = []
		for row in data_rows:
			if id != row.Split("@")[0]:
				new_rows.append(row)
		data_rows = new_rows
		try:
			with db.Transaction(name = "Set Meta"):
				self.Element.get_Parameter(Guid("ae55daa4-8182-4510-a017-32518bdfd3ce")).Set(self.GetMeta())
		except Exception as e: 
			print(str(e))
			pass
		data_rows.append("@".join([str(self.Element.Id.IntegerValue),
				str(self.Element.Location.Point.X),
				str(self.Element.Location.Point.Y),
				str(self.Element.Location.Point.Z),
				str(self.Element.LookupParameter("КП_Р_Высота").AsDouble()),
				str(self.Element.LookupParameter("КП_Р_Ширина").AsDouble()),
				str(self.Element.get_Parameter(DB.BuiltInParameter.INSTANCE_ELEVATION_PARAM).AsDouble()),
				str(self.Element.LevelId.IntegerValue),
				str(self.Element.get_Parameter(Guid("ae55daa4-8182-4510-a017-32518bdfd3ce")).AsString()),
				"Задание утверждено",
				str(self.TBox.Text)]))
		try:
			with db.Transaction(name = "Update Meta"):
				doc.ProjectInformation.get_Parameter(Guid("374f4f6f-ff4c-412e-9c30-07796373f0bc")).Set("\n".join(data_rows))
		except Exception as e: 
			print(str(e))
			pass

	def Zoom(self, sender, args):
		try:
			self.ActivateView(self.Element)
		except:
			pass

	def ActivateView(self, element):
		try:
			if uidoc.ActiveView.get_Parameter(DB.BuiltInParameter.VIEW_NAME).AsString() != "SYS_OPENINGS" and str(uidoc.ActiveView.ViewType) != "ThreeD":
				collector_viewFamily = DB.FilteredElementCollector(doc).OfClass(DB.View3D).WhereElementIsNotElementType()
				bool = False
				for view in collector_viewFamily:
					if view.get_Parameter(DB.BuiltInParameter.VIEW_NAME).AsString() == "SYS_OPENINGS":
						zview = view
						bool = True
						uidoc.ActiveView = zview
				if not bool:
					collector_viewFamilyType = DB.FilteredElementCollector(doc).OfClass(DB.ViewFamilyType).WhereElementIsElementType()
					for view in collector_viewFamilyType:
						if view.ViewFamily == DB.ViewFamily.ThreeDimensional:
							viewFamilyType = view
							break
					with db.Transaction(name = "CreateView"):
						zview = DB.View3D.CreateIsometric(doc, viewFamilyType.Id)
						zview.get_Parameter(DB.BuiltInParameter.VIEW_NAME).Set("SYS_OPENINGS")
					return False
			a_view = uidoc.ActiveView
			with db.Transaction(name = "Reset"):
				a_view.CropBoxActive = False
			with db.Transaction(name = "ModifyView"):
				pt = DB.XYZ(0,0,0)
				clipbox = DB.BoundingBoxXYZ()
				clipbox.Min = DB.XYZ(element.Location.Point.X + pt.X - 10, element.Location.Point.Y + pt.Y - 10, element.Location.Point.Z - 10)
				clipbox.Max = DB.XYZ(element.Location.Point.X + pt.X + 10, element.Location.Point.Y + pt.Y + 10, element.Location.Point.Z + 5)
				a_view.SetSectionBox(clipbox)
				eye_position = DB.XYZ(element.Location.Point.X, element.Location.Point.Y, element.Location.Point.Z)
				forward_direction = self.VectorFromHorizVertAngles(135, -30)
				up_direction = self.VectorFromHorizVertAngles(135, -30 + 90 )
				orientation = DB.ViewOrientation3D(eye_position, up_direction, forward_direction)
				a_view.SetOrientation(orientation)
			with db.Transaction(name = "Colorify"):
				for workset in DB.FilteredWorksetCollector(doc).OfKind(DB.WorksetKind.UserWorkset).ToWorksets():
					try:
						a_view.SetWorksetVisibility(workset.Id, DB.WorksetVisibility.Visible)
					except: pass
				a_view.DetailLevel = DB.ViewDetailLevel.Fine
				self.ZoomBbox(element, a_view, clipbox)
		except:
			return False
		return True

	def VectorFromHorizVertAngles(self, angleHorizD, angleVertD):
		degToRadian = math.pi * 2 / 360
		angleHorizR = angleHorizD * degToRadian
		angleVertR = angleVertD * degToRadian
		a = math.cos(angleVertR)
		b = math.cos(angleHorizR)
		c = math.sin(angleHorizR)
		d = math.sin(angleVertR)
		return DB.XYZ(a*b, a*c, d)

	def ZoomBbox(self, element, view, box):
		try:
			gelements = []
			gelements.append(element)
			selection = uidoc.Selection
			collection = List[DB.ElementId]([el.Id for el in gelements])
			selection.SetElementIds(collection)
		except: pass
		views = uidoc.GetOpenUIViews()
		for v in views:
			if str(v.ViewId) == str(view.Id):
				v.ZoomAndCenterRectangle(box.Min, box.Max)

class Parser(Form):
	def __init__(self):
		global elements
		self.Name = "KPLN_MEP_Monitoring"
		self.Text = "KPLN Координация : Мониторинг"
		self.Size = Size(615, 600)
		self.MinimumSize = Size(615, 350)
		self.MaximumSize = Size(615, 1000)
		self.MaximizeBox = False
		self.MinimizeBox = False
		self.ControlBox = True
		self.FormBorderStyle = FormBorderStyle.Sizable
		self.TopMost = True
		self.AutoScroll = True
		self.Max = 100
		self.Tabs = []
		#
		self.label_title = Label()
		self.label_title.Parent = self
		self.label_title.Location = Point(10,10)
		self.label_title.Size = Size(500, 20)
		self.label_title.Text = "Список измененных и неодобренных элементов:"
		self.label_title.Font = Font("Arial", 12, FontStyle.Bold)

		self.label_description = Label()
		self.label_description.Parent = self
		self.label_description.Location = Point(12,30)
		self.label_description.Size = Size(500, 50)
		self.label_description.Text = "Примечания:\n - Запрещено отменять изменения и дальнейшее использование открытого окна после отмены\n   (необходимо закрыть и запустить мониторинг заново);"
		#
		for element in elements:
			self.Tabs.append(Tab(self, self.Max, element))
			self.Max += 210

class MonitoringElement():
	def __init__(self, element):
		self.Element = element
		self.IsApproved = None
		self.IsChanged = None
		self.IsMonitoring = None
		self.DataRow = self.GetDataRow()
		#
		self.LocationChanged = None
		self.HeightChanged = None
		self.WidthChanged = None
		self.OffsetChanged = None
		self.LevelChanged = None
		self.MetaData = []
		self.MetaString = ""
		self.Comments = ""
		try:
			if self.DataRow != None:
				self.IsMonitoring = True
				self.Comments = self.DataRow[10]
				self.MetaData = self.DataRow[8].Split('#')
				self.MetaString = "Дата изменения: {}/{}/{} {}:{}:{}\nПользователь: {}".format(self.MetaData[0],
								self.MetaData[1],
								self.MetaData[2],
								self.MetaData[3],
								self.MetaData[4],
								self.MetaData[5],
								self.MetaData[6])
				if self.DataRow[9] == "Задание утверждено":
					self.IsApproved = True
					if self.DataRow[1] == str(self.Element.Location.Point.X) and self.DataRow[2] == str(self.Element.Location.Point.Y) and self.DataRow[3] == str(self.Element.Location.Point.Z):
						self.LocationChanged = False
					else:
						self.LocationChanged = True
					self.HeightChanged = not self.DataRow[4] == str(self.Element.LookupParameter("КП_Р_Высота").AsDouble())
					self.WidthChanged = not self.DataRow[5] == str(self.Element.LookupParameter("КП_Р_Ширина").AsDouble())
					self.OffsetChanged = not self.DataRow[6] == str(self.Element.get_Parameter(DB.BuiltInParameter.INSTANCE_ELEVATION_PARAM).AsDouble())
					self.LevelChanged = not self.DataRow[7] == str(self.Element.LevelId.IntegerValue)
					if self.LocationChanged or self.HeightChanged or self.WidthChanged or self.OffsetChanged or self.LevelChanged:
						self.IsChanged = True
					else:
						self.IsChanged = False
				else:
					if self.DataRow[1] == str(self.Element.Location.Point.X) and self.DataRow[2] == str(self.Element.Location.Point.Y) and self.DataRow[3] == str(self.Element.Location.Point.Z):
						self.LocationChanged = False
					else:
						self.LocationChanged = True
					self.HeightChanged = not self.DataRow[4] == str(self.Element.LookupParameter("КП_Р_Высота").AsDouble())
					self.WidthChanged = not self.DataRow[5] == str(self.Element.LookupParameter("КП_Р_Ширина").AsDouble())
					self.OffsetChanged = not self.DataRow[6] == str(self.Element.get_Parameter(DB.BuiltInParameter.INSTANCE_ELEVATION_PARAM).AsDouble())
					self.LevelChanged = not self.DataRow[7] == str(self.Element.LevelId.IntegerValue)
					if self.LocationChanged or self.HeightChanged or self.WidthChanged or self.OffsetChanged or self.LevelChanged:
						self.IsChanged = True
					else:
						self.IsChanged = False
					self.IsApproved = False
					self.IsChanged = False

			else:
				print("-")
				self.IsChanged = False
				self.IsMonitoring = False
				self.IsApproved = False
		except:
			self.Data = []
			self.IsApproved = False
			self.IsMonitoring = False
			self.IsChanged = False
			self.MetaData = []
			self.MetaString = ""
			self.Comments = ""

	def UpdateMeta(self):
		log_username = System.Security.Principal.WindowsIdentity.GetCurrent().Name.split('\\')
		system_username = log_username[len(log_username) - 1]
		now = datetime.datetime.now()
		self.MetaData =  [str(now.year), str(now.month), str(now.day), str(now.hour), str(now.minute), str(now.second), system_username]

	def GetDataRow(self):
		global data_rows
		current_row = []
		try:
			for row in data_rows:
				try:
					if str(self.Element.Id.IntegerValue) == row.Split("@")[0]:
						current_row = row.Split("@")
				except Exception as e: print(str(e))
		except Exception as e: print(str(e))
		if len(current_row) == 0:
			current_row = [str(self.Element.Id.IntegerValue),
				str(self.Element.Location.Point.X),
				str(self.Element.Location.Point.Y),
				str(self.Element.Location.Point.Z),
				str(self.Element.LookupParameter("КП_Р_Высота").AsDouble()),
				str(self.Element.LookupParameter("КП_Р_Ширина").AsDouble()),
				str(self.Element.get_Parameter(DB.BuiltInParameter.INSTANCE_ELEVATION_PARAM).AsDouble()),
				str(self.Element.LevelId.IntegerValue),
				"#".join(["????", "??", "??", "??", "??", "??", "Undefined"]),
				"Под вопросом",
				"Незадекларированный элемент!"]
			data_rows.append("@".join(current_row))
			with db.Transaction(name = "Update Meta"):
				doc.ProjectInformation.get_Parameter(Guid("374f4f6f-ff4c-412e-9c30-07796373f0bc")).Set("\n".join(data_rows))
		return current_row

	@property
	def Element(self):
		return self.Element

	@property
	def IsApproved(self):
		return self.IsApproved

	@property
	def IsChanged(self):
		return self.IsChanged

	@property
	def IsMonitoring(self):
		return self.IsMonitoring

	@property
	def LocationChanged(self):
		return self.LocationChanged

	@property
	def HeightChanged(self):
		return self.HeightChanged

	@property
	def WidthChanged(self):
		return self.WidthChanged

	@property
	def OffsetChanged(self):
		return self.OffsetChanged

	@property
	def LevelChanged(self):
		return self.LevelChanged

	@property
	def MetaString(self):
		return self.MetaString

	@property
	def Comments(self):
		return self.Comments

if uidoc.ActiveView.get_Parameter(DB.BuiltInParameter.VIEW_NAME).AsString() != "SYS_OPENINGS" and str(uidoc.ActiveView.ViewType) != "ThreeD":
	collector_viewFamily = DB.FilteredElementCollector(doc).OfClass(DB.View3D).WhereElementIsNotElementType()
	bool = False
	for view in collector_viewFamily:
		if view.get_Parameter(DB.BuiltInParameter.VIEW_NAME).AsString() == "SYS_OPENINGS":
			zview = view
			bool = True
			uidoc.ActiveView = zview
	if not bool:
		collector_viewFamilyType = DB.FilteredElementCollector(doc).OfClass(DB.ViewFamilyType).WhereElementIsElementType()
		for view in collector_viewFamilyType:
			if view.ViewFamily == DB.ViewFamily.ThreeDimensional:
				viewFamilyType = view
				break
		with db.Transaction(name = "CreateView"):
			zview = DB.View3D.CreateIsometric(doc, viewFamilyType.Id)
			zview.get_Parameter(DB.BuiltInParameter.VIEW_NAME).Set("SYS_OPENINGS")

elements = []
ids = []
ids_appended = []
data_rows = []
for element in DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_MechanicalEquipment).WhereElementIsNotElementType().ToElements():
	if element.Symbol.FamilyName == "501_Задание на отверстие в стене круглое" or element.Symbol.FamilyName == "501_Задание на отверстие в стене прямоугольное":
		ids.append(str(element.Id.IntegerValue))

optimised_rows = []
try:
	data_rows = doc.ProjectInformation.get_Parameter(Guid("374f4f6f-ff4c-412e-9c30-07796373f0bc")).AsString().Split("\n")
	for row in data_rows:
		if row.Split("@")[0] in ids and not row.Split("@")[0] in ids_appended:
			optimised_rows.append(row)
			ids_appended.append(row.Split("@")[0])
	data_rows = optimised_rows
	try:
		with db.Transaction(name = "Update Meta"):
			doc.ProjectInformation.get_Parameter(Guid("374f4f6f-ff4c-412e-9c30-07796373f0bc")).Set("\n".join(data_rows))
	except Exception as e:
		print(str(e))
except: pass

for element in DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_MechanicalEquipment).WhereElementIsNotElementType().ToElements():
	if element.Symbol.FamilyName == "501_Задание на отверстие в стене круглое" or element.Symbol.FamilyName == "501_Задание на отверстие в стене прямоугольное":
		ids.append(str(element.Id.IntegerValue))
		monitoring_element = MonitoringElement(element)
		if monitoring_element.IsApproved == False or monitoring_element.IsChanged == True:
			elements.append(monitoring_element)

if len(elements) != 0:
	form = Parser()
	Application.Run(form)
else:
	TD = UI.TaskDialog("KPLN Координация : Мониторинг")
	TD.TitleAutoPrefix = False
	TD.MainInstruction = ": )"
	TD.MainContent = "Измененных элементов не найдено!"
	TD.FooterText = "Что-то не так? - см. «База знаний»"
	TD.Show()
